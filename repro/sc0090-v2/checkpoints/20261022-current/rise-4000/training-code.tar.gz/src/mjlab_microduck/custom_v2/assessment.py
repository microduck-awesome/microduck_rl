"""Declared behavior protocols and CPU analysis of recorded physical signals.

Thresholds are explicit experiment acceptance targets, not claims that the
current policy passes or that sim-to-real transfer has been established.
"""
import math
import torch
from mjlab_microduck.tasks import mdp

DT=.02
PROTOCOL_VERSION=4
CRITERIA=dict(response_deadline_s=2.,continuous_hold_s=.5,overshoot_fraction=.30,
    head_absolute_band_rad=.003,head_relative_band=.20,
    straight_min_progress_fraction=.70,straight_cross_track_m_per_m=.05,
    straight_max_heading_deg=5.,stop_leg_speed_rad_s=.25,
    moving_camera_rms_rad_s=2.,idle_camera_rms_rad_s=.3,
    moving_head_absolute_band_rad=.02,standing_head_mean_tau_s=.1,moving_head_mean_tau_s=1.,
    moving_head_response_deadline_s=3.,initial_response_fraction=.1,
    standing_balance_band_deg=4.,standing_balance_mean_tau_s=.15,
    standing_balance_rate_rad_s=.35,standing_balance_prediction_s=.25)


def cases_for(protocol):
    if protocol=='recovery':
        return [dict(name=x)for x in ('standing','sitting','prone','frontier','left_side','right_side','supine')]
    if protocol=='tilt':
        return [dict(name='neutral',pitch_deg=0,roll_deg=0,outward_rate_rad_s=0.)]+[
            dict(name=f'{direction}_{degrees}_{rate:.1f}',direction=direction,
                 pitch_deg=sign*degrees if axis=='pitch'else 0,
                 roll_deg=sign*degrees if axis=='roll'else 0,outward_rate_rad_s=rate)
            for direction,axis,sign in [('back','pitch',-1),('front','pitch',1),('left','roll',-1),('right','roll',1)]
            for degrees in (2,5,10)for rate in (0.,.1,.3)]
    if protocol in ('four_way_push','slow_push','fast_push'):
        rows=[]
        for direction,name in enumerate(('back','front','left','right')):
            for level,peak in enumerate((.25,.45,.7)):
                for mode,duration,nominal in ((0,.32,.12),(1,1.6,.8)):
                    if protocol=='slow_push'and mode==0:continue
                    if protocol=='fast_push'and mode==1:continue
                    rows.append(dict(name=f'{name}_{peak:.2f}_'+('sustained'if mode else 'pulse'),
                        direction=direction,mode=mode,peak=peak,duration=duration,old_nominal_s=nominal,level=level))
        return rows
    if protocol=='head':
        rows=[dict(name='head_zero',head=[0.]*4)]
        for i,name in enumerate(('neck_pitch','head_pitch','head_yaw','head_roll')):
            for amplitude in (.01,.03,.10):
                for sign in (-1,1):
                    c=[0.]*4;c[i]=amplitude*sign
                    rows.append(dict(name=f'{name}_{amplitude*sign:+.2f}',head=c))
        rows.append(dict(name='head_combined',head=[.03,-.03,.03,-.03]))
        return rows
    if protocol=='straight':
        return [dict(name=f'straight_{sign*v:+.2f}',twist=[sign*v,0.,0.])
                for v in (.03,.05,.1,.3)for sign in (-1,1)]
    if protocol=='walking':
        rows=[dict(name='idle',twist=[0.]*3)]
        for i,name,values in [(0,'forward',(.03,.05,.1,.3,.4)),(1,'lateral',(.03,.1,.3)),(2,'yaw',(.15,.5,1.))]:
            for v in values:
                for sign in (-1,1):
                    c=[0.]*3;c[i]=v*sign;rows.append(dict(name=f'{name}_{v*sign:+.2f}',twist=c))
        for sign in (-1,1):
            for name,c,h in [('curve',[.2,0.,.7*sign],[0.]*4),('diagonal',[.15,.15*sign,0.],[0.]*4),
                              ('walking_head',[.2,0.,0.],[.05*sign,-.05*sign,.07*sign,.015*sign])]:
                rows.append(dict(name=f'{name}_{sign:+}',twist=c,head=h))
        return rows
    raise ValueError('Unknown protocol')


def duration_for(protocol):
    return 28. if protocol=='straight'else 16. if protocol in ('walking','head')else 12. if 'push'in protocol else 8.


def command_multiplier(time_s,protocol):
    if protocol=='straight':return float(2.<=time_s<26.)
    if protocol in ('walking','head'):
        return 1. if 2.<=time_s<6. else -1. if 8.<=time_s<12. else 0.
    return 0.


def _first(mask):
    indices=mask.nonzero().flatten()
    return None if not len(indices)else float(indices[0])*DT


def response_metrics(signal,command,*,head=False,moving_head=False):
    """T10/T90 and settling measured from THIS signal's command transitions.

    Velocity input is the training 0.5s EMA. Head input is a 0.1s physical mean
    (1s mean for moving head control); raw error is reported separately.
    """
    changes=(command[1:]!=command[:-1]).any(-1).nonzero().flatten()+1
    starts=changes.tolist();rows=[];hold=round(CRITERIA['continuous_hold_s']/DT)
    deadline=CRITERIA['moving_head_response_deadline_s'if moving_head else 'response_deadline_s']
    for index,start in enumerate(starts):
        end=starts[index+1]if index+1<len(starts)else len(signal)
        target=command[start];old=command[start-1]
        changed=(target-old).abs()>1e-7
        values=signal[start:end];baseline=signal[max(0,start-10):start].mean(0)
        if head:
            floor=CRITERIA['moving_head_absolute_band_rad']if moving_head else CRITERIA['head_absolute_band_rad']
            band=torch.maximum(target.abs()*CRITERIA['head_relative_band'],torch.full_like(target,floor))
        else:band=mdp.sim2real_velocity_band(target)
        axes=[]
        for axis in changed.nonzero().flatten().tolist():
            delta=target[axis]-baseline[axis];amplitude=delta.abs()
            # A loose steady-state band must not mark an unresponsive small
            # command as already answered. This bound is tied to the requested
            # change, independently of natural-motion tracking tolerance.
            response_band=max(float((target[axis]-old[axis]).abs())*CRITERIA['initial_response_fraction'],1e-4)
            already=bool(amplitude<=response_band)
            progress=(values[:,axis]-baseline[axis])*delta.sign()/amplitude.clamp_min(1e-7)
            t10=0. if already else _first(progress>=.1)
            t90=0. if already else _first(progress>=.9)
            overshoot=float(((values[:,axis]-target[axis])*delta.sign()).clamp_min(0).max())
            overshoot_limit=max(float(amplitude)*CRITERIA['overshoot_fraction'],float(band[axis]))
            axes.append(dict(axis=axis,t10_s=t10,t90_s=t90,initially_in_band=already,
                overshoot=overshoot,overshoot_limit=overshoot_limit,
                response_pass=t90 is not None and t90<=deadline and overshoot<=overshoot_limit))
        in_band=((values-target).abs()<=band).all(-1)
        windows=in_band.unfold(0,hold,1).all(-1)if len(values)>=hold else torch.zeros(0,dtype=torch.bool)
        settle=_first(windows)
        tail_pass=bool(in_band[-hold:].all())if len(values)>=hold else False
        rows.append(dict(start_s=start*DT,end_s=end*DT,target=target.tolist(),axes=axes,
            band=band.tolist(),settling_start_s=settle,tail_hold_pass=tail_pass,
            pass_response=bool(axes)and all(x['response_pass']for x in axes)and
                settle is not None and settle<=deadline and tail_pass,response_deadline_s=deadline))
    return rows


def physical_head_mean(position,moving=False):
    mean=position[0].clone();rows=[];alpha=1-math.exp(-DT/CRITERIA['moving_head_mean_tau_s'if moving else 'standing_head_mean_tau_s'])
    for value in position:
        mean=mean+alpha*(value-mean);rows.append(mean)
    return torch.stack(rows)


def straight_metrics(position,yaw,command):
    indices=(command[:,:2].norm(dim=-1)>.01).nonzero().flatten()
    if not len(indices):return None
    a,b=int(indices[0]),int(indices[-1]);theta=yaw[a]
    local=command[a,:2]/command[a,:2].norm()
    direction=torch.stack((local[0]*theta.cos()-local[1]*theta.sin(),local[0]*theta.sin()+local[1]*theta.cos()))
    side=torch.stack((-direction[1],direction[0]))
    delta=position[a:b+1,:2]-position[a,:2]
    forward=delta@direction;cross=delta@side
    progress=float(forward[-1]);expected=float(command[a,:2].norm())*(b-a)*DT
    enough=progress>=max(.25,expected*CRITERIA['straight_min_progress_fraction'])
    heading=torch.atan2(torch.sin(yaw[a:b+1]-theta),torch.cos(yaw[a:b+1]-theta))*180/math.pi
    drift=float(cross.abs().max())/progress if progress>.01 else None
    return dict(duration_s=(b-a)*DT,forward_progress_m=progress,requested_progress_m=expected,
        maximum_cross_track_m=float(cross.abs().max()),cross_track_m_per_m=drift,
        maximum_heading_error_deg=float(heading.abs().max()),
        endpoint_heading_deg_per_m=float(heading[-1].abs())/progress if progress>.01 else None,
        sufficient_progress=enough,pass_straight=enough and drift<=CRITERIA['straight_cross_track_m_per_m']and float(heading.abs().max())<=CRITERIA['straight_max_heading_deg'])


def summarize(data,cases,samples,protocol):
    finite=torch.isfinite(data['qpos']).all(-1)&torch.isfinite(data['qvel']).all(-1)
    healthy,recovered,quiet,fall=mdp.sim2real_body_criteria(data['height'],data['tilt'],data['lin'],data['ang'],
        data['feet'],data['head_contact'],data['self_contact'],finite)
    if not torch.equal(recovered,data['stable'])or not torch.equal(quiet,data['quiet']):
        raise AssertionError('Training and evaluation body definitions differ')
    angles=torch.stack((data['roll'],data['pitch']),-1)
    # Start from the logged reward-boundary mean. It may already contain the
    # reset observation; replay every later update and verify the same source.
    mean=data['balance_mean'][0].clone()if 'balance_mean'in data else angles[0].clone()
    filtered=[mean.clone()];alpha=1-math.exp(-DT/.15)
    for value in angles[1:]:mean=mean+alpha*(value-mean);filtered.append(mean.clone())
    filtered=torch.stack(filtered)
    _,settled=mdp.sim2real_balance_band(filtered,data['ang'][...,:2],quiet)
    if 'balance_mean'in data:
        torch.testing.assert_close(filtered,data['balance_mean'],rtol=1e-5,atol=1e-6)
        if not torch.equal(settled,data['settled']):raise AssertionError('Training and evaluation balance definitions differ')
    rows=[]
    for i,case in enumerate(cases):
        worlds=[]
        for world in range(i*samples,(i+1)*samples):
            if not bool(finite[:,world].all())or not bool(torch.isfinite(data['head_position'][:,world]).all()):
                worlds.append(dict(finite=False,qualified=False,failure='nonfinite physical trajectory'))
                continue
            good=healthy[:,world]&~data['self_contact'][:,world]
            body_holds=recovered[:,world].unfold(0,25,1).all(-1)
            indices=body_holds.nonzero().flatten()
            first=None if not len(indices)else int(indices[0])+24
            never_fell=not bool(fall[:,world].any())
            velocity=response_metrics(data['velocity_mean'][:,world],data['previous_command'][:,world])
            moving=bool(data['previous_command'][:,world].abs().any())
            head_mean=physical_head_mean(data['head_position'][:,world],moving)
            head=response_metrics(head_mean,data['head_command'][:,world],head=True,moving_head=moving)
            head_tail_pass=bool(((head_mean[-25:]-data['head_command'][-25:,world]).abs()<=CRITERIA['moving_head_absolute_band_rad'if moving else 'head_absolute_band_rad']).all())
            idle=(data['previous_command'][:,world]==0).all(-1)&(data['command_age'][:,world]>=25)
            idle_good=settled[:,world]&(data['leg_speed'][:,world]<CRITERIA['stop_leg_speed_rad_s'])
            idle_good &= mdp.sim2real_velocity_tracking(data['velocity_mean'][:,world],torch.zeros_like(data['previous_command'][:,world]))
            # Final 0.5s must be truly quiet, not a transient zero crossing.
            stop_pass=bool(idle_good[-25:].all())
            row=dict(finite=bool(finite[:,world].all()),never_fell=never_fell,
                body_stable_tail=bool(body_holds[-1]),quiet_stop_tail=stop_pass,
                first_body_stable_s=None if first is None else (first+1)*DT,
                fell_after_stability=False if first is None else bool(fall[first:,world].any()),
                head_contact=bool(data['head_contact'][:,world].any()),self_contact=bool(data['self_contact'][:,world].any()),
                velocity_responses=velocity,head_responses=head,head_tail_pass=head_tail_pass,
                head_raw_mae_deg=((data['head_position'][:,world]-data['head_command'][:,world]).abs().mean(0)*180/math.pi).tolist(),
                idle_leg_speed_rad_s=float(data['leg_speed'][idle,world].mean())if bool(idle.any())else None,
                camera_rms_rad_s=float(data['camera_energy'][:,world].mean().sqrt())if 'camera_energy'in data else None)
            if 'camera_energy'in data:
                active=(data['previous_command'][:,world].abs().amax(-1)>.01)&(data['command_age'][:,world]>=25)
                row['moving_camera_rms_rad_s']=float(data['camera_energy'][active,world].mean().sqrt())if bool(active.any())else None
                row['idle_tail_camera_rms_rad_s']=float(data['camera_energy'][-25:,world].mean().sqrt())
            if protocol=='straight':row['straight']=straight_metrics(data['qpos'][:,world,:3],data['yaw'][:,world],data['previous_command'][:,world])
            if protocol=='tilt'or 'push'in protocol:
                a=angles[:,world];omega=data['ang'][:,world,:2]
                windows=settled[:,world].unfold(0,25,1).all(-1)
                row['balance']=dict(band_deg=4.,initially_in_band=bool(settled[0,world]),
                    first_settling_window_s=_first(windows),
                    first_inward_motion_s=_first((a*omega).sum(-1)<-math.radians(.1)),
                    maximum_tilt_deg=float(data['tilt'][:,world].max())*180/math.pi,
                    tail_angle_peak_to_peak_deg=((a[-25:].max(0).values-a[-25:].min(0).values)*180/math.pi).tolist(),
                    tail_angular_rms_rad_s=float(omega[-25:].square().sum(-1).mean().sqrt()))
            if 'push'in protocol:
                force=data['applied_force'][:,world,0,:];norm=force.norm(dim=-1);active=norm>0
                applied=float(active.sum())*DT;impulse=float(norm.sum())*DT
                actual_indices=active.nonzero().flatten()
                end=None if not len(actual_indices)else int(actual_indices[-1])+1
                recovery=None
                if end is not None:
                    holds=settled[end:,world].unfold(0,25,1).all(-1)
                    recovery=_first(holds)
                row['push']=dict(actual_duration_s=applied,requested_duration_s=case['duration'],
                    old_nominal_s=case['old_nominal_s'],impulse_Ns=impulse,
                    duration_complete=abs(applied-case['duration'])<DT/2,
                    initial_quiet=bool(settled[75:100,world].all()),recovery_window_start_s=recovery)
            qualified=never_fell and bool(good.all())and stop_pass
            if protocol=='recovery':qualified=bool(body_holds[-1])and not row['fell_after_stability']
            elif protocol=='straight':qualified &= row['straight']['pass_straight']
            elif protocol=='tilt':
                settling=row['balance']['first_settling_window_s']
                qualified &= settling is not None and settling<=2.5
            elif 'push'in protocol:
                p=row['push'];qualified &= p['duration_complete']and p['initial_quiet']and p['recovery_window_start_s']is not None and p['recovery_window_start_s']<=.5
            else:
                qualified &= all(x['pass_response']for x in velocity+head)
            if protocol in ('head','walking','straight'):
                qualified &= head_tail_pass
                if 'camera_energy'in data:
                    qualified &= row['idle_tail_camera_rms_rad_s']<=CRITERIA['idle_camera_rms_rad_s']
                    if row['moving_camera_rms_rad_s']is not None:qualified &= row['moving_camera_rms_rad_s']<=CRITERIA['moving_camera_rms_rad_s']
            row['qualified']=bool(qualified);worlds.append(row)
        rows.append(dict(**case,trials=samples,wins=sum(x['qualified']for x in worlds),worlds=worlds))
    return rows
