"""Checkpoint and isolated-assessment orchestration for the fresh baseline.

MDP behavior remains in tasks/mdp.py. Evaluation copies the training recipe
before reducing world count, and never changes the live training simulator.
"""
from copy import deepcopy
from dataclasses import asdict
import gc,hashlib,json,random
import numpy as np
import torch
from mjlab_microduck.tasks import mdp
from .sim2real import ROOT,model_path,configure_batch_size,RANDOMIZATION_CONTRACT,WALK_TASK,RISE_TASK

KEY='sim2real_baseline_20261021'
SCALARS=('stage','last_promotion','last_review','window_cursor','push_stage','balance_stage')
TENSORS=('counts','wins','window_counts','window_wins','last_rates',
         'balance_counts','balance_wins','balance_window_counts','balance_window_wins','balance_rates',
         'push_counts','push_wins','push_window_counts','push_window_wins','push_rates',
         'push_total_counts','push_total_wins','push_total_truncated','push_total_seconds','push_total_impulse')
HEAD_BUDGET_REFERENCE_UPDATES=256
EVAL_SEEDS=(2026102102,2026102103)
COMMAND_RELEASE_SOURCE_RECIPE='01efdc1b34c6b824ae4a8e0a1467605e84a2d765c0c7075963de94e319e1d55a'
UPRIGHT_HEAD_SOURCE_RECIPE='112b1adb92dc25319964e06a229bcd91fc092245611c56075b5168c610a7ec46'
BODY_REPLAY_SOURCE_RECIPE='544d4b43bffaf81a9a057373cca9343845940cd9a174caae1e7c807ee3d397da'


def recipe_sha256():
    paths=sorted((ROOT/'src').rglob('*.py'))+[
        ROOT/'scripts'/name for name in ('train_v2_sim2real.py','evaluate_v2_sim2real.py','validate_v2_sim2real.py')]
    paths.append(ROOT/'src/mjlab_microduck/custom_v2/assets/sim2real_balance_poses.json')
    digest=hashlib.sha256()
    for path in paths:
        digest.update(str(path.relative_to(ROOT)).encode());digest.update(path.read_bytes())
    return digest.hexdigest()


def normal_buffer_lifetimes(model):
    with torch.inference_mode(False),torch.no_grad():
        for module in model.modules():
            for name,value in module._buffers.items():
                if value is not None and value.is_inference():
                    module._buffers[name]=value.clone()


def capture_rng(env=None):
    result=dict(cpu=torch.get_rng_state(),cuda=torch.cuda.get_rng_state_all(),
                numpy=np.random.get_state(),python=random.getstate())
    if env is not None:result['paired']=env._v2_error_blocks.rng.get_state()
    return result


def restore_rng(state,env=None):
    torch.set_rng_state(state['cpu'].cpu())
    torch.cuda.set_rng_state_all([x.cpu()for x in state['cuda']])
    np.random.set_state(state['numpy']);random.setstate(state['python'])
    if env is not None:env._v2_error_blocks.rng.set_state(state['paired'].cpu())


def batch_contract(env):
    n=env._sim2real_training_num_envs;mini=4 if n==64 else 4*n//8192
    return dict(reference_envs=8192,num_envs=n,rollout_steps=24,minibatches=mini,
                samples_per_minibatch=n*24//mini,epochs=5,
                reference_learning_step_factor=env._sim2real_reference_factor,
                physical_time_unchanged=True)


def checkpoint_record(env):
    s=mdp.sim2real_state(env)
    course={k:s[k]for k in SCALARS}
    course.update({k:s[k].detach().cpu().clone()for k in TENSORS})
    recovery=None
    if env._sim2real_kind=='rise':
        r=mdp.sim2real_recovery_state(env)
        recovery={**deepcopy(r.state_dict()),'discovery':r.discovery}
    return dict(schema=3,kind=env._sim2real_kind,recipe_sha256=recipe_sha256(),
        randomization_contract=deepcopy(RANDOMIZATION_CONTRACT),
        geometry_sha256=hashlib.sha256(model_path(env._sim2real_kind).read_bytes()).hexdigest(),
        batch_contract=batch_contract(env),curriculum=course,recovery=recovery,
        common_step_counter=env.common_step_counter,
        eval_history=deepcopy(getattr(env,'_sc0090_eval_history',{})),
        precision_start_reference_step=env._sim2real_precision_start,
        precision_budget_reference_updates=HEAD_BUDGET_REFERENCE_UPDATES,
        migration_history=deepcopy(getattr(env,'_sim2real_migration_history',[])),
        episode_restore='new episodes; no physics continuation')


def validate_record(record,kind):
    if (not record or record.get('schema')!=3 or record.get('kind')!=kind or
        record.get('recipe_sha256')!=recipe_sha256() or
        record.get('geometry_sha256')!=hashlib.sha256(model_path(kind).read_bytes()).hexdigest()):
        raise ValueError('Checkpoint requires this exact task, geometry and repaired learning recipe')


def migrate_live_repair_record(record,source_checkpoint_sha256,qualification):
    """One explicit, traced repair transition; ordinary resume stays strict.

    Only the authorized frozen recipe is accepted. Policy/optimizer, clocks
    and ability stages remain intact. Walking discards its affected recent
    command statistics; the rise resource-lifetime fix changes no MDP data.
    """
    kind=record.get('kind');task={'walk':WALK_TASK,'rise':RISE_TASK}.get(kind)
    source=record.get('recipe_sha256')
    supported=(source==COMMAND_RELEASE_SOURCE_RECIPE or
               (kind=='rise'and source in (UPRIGHT_HEAD_SOURCE_RECIPE,BODY_REPLAY_SOURCE_RECIPE)))
    if (record.get('schema')!=3 or task is None or
        record.get('allocation_kind')!='formal' or
        not supported or
        record.get('geometry_sha256')!=hashlib.sha256(model_path(kind).read_bytes()).hexdigest() or
        record.get('randomization_contract')!=RANDOMIZATION_CONTRACT):
        raise ValueError('Only the frozen formal recipe supports this repair transition')
    target=recipe_sha256()
    if (qualification.get('status')!='PASS' or qualification.get('task')!=task or
        qualification.get('num_envs')!=record['batch_contract']['num_envs'] or
        qualification.get('recipe_sha256')!=target):
        raise ValueError('Repair transition requires matching task, batch and source qualification')
    migrated=deepcopy(record)
    reset=('counts','wins','window_counts','window_wins','last_rates')if kind=='walk'else ()
    for key in reset:migrated['curriculum'][key].zero_()
    migrated['recipe_sha256']=target
    repair=('release_walking_command_when_standing_trial_ends'if kind=='walk'else
            'activate_broad_head_tracking_after_upright_arrival')
    if kind=='rise'and source==COMMAND_RELEASE_SOURCE_RECIPE:
        repair='release_isolated_assessment_resources_and_'+repair
    if kind=='rise'and source==BODY_REPLAY_SOURCE_RECIPE:
        repair='deterministic_body_threshold_replay_and_preserve_assessed_resume'
    migrated.setdefault('migration_history',[]).append(dict(
        repair=repair,
        source_checkpoint_sha256=source_checkpoint_sha256,
        source_recipe_sha256=source,target_recipe_sha256=target,
        completed_updates=record['completed_updates'],reset_recent_statistics=list(reset),
        policy_optimizer_normalizer_clocks_and_stages='preserved',
        physics='new episodes, as for ordinary resume'))
    validate_record(migrated,kind)
    return migrated


def apply_checkpoint_recipe(cfg,agent,record,*,evaluation_num_envs=None):
    kind=cfg.events['sim2real_initialize'].params['kind']
    validate_record(record,kind)
    actual=configure_batch_size(cfg,agent,record['batch_contract']['num_envs'])
    if actual!=record['batch_contract']:raise ValueError('Unsupported training batch contract')
    if evaluation_num_envs is not None:cfg.scene.num_envs=evaluation_num_envs
    return actual


def restore_learning_state(env,record):
    s=mdp.sim2real_state(env)
    # No physical pulse/episode is resumed; do not count the pre-load live
    # environment as a truncated trial against restored checkpoint statistics.
    s['push_trial'].zero_()
    s['balance_trial'].zero_()
    for k in SCALARS:s[k]=record['curriculum'][k]
    for k in TENSORS:s[k].copy_(record['curriculum'][k].to(s[k]))
    if record['recovery'] is not None:
        r=mdp.sim2real_recovery_state(env)
        r.load_state_dict(record['recovery']);r.discovery=record['recovery']['discovery']
    env._sc0090_eval_history=deepcopy(record['eval_history'])
    env._sim2real_migration_history=deepcopy(record.get('migration_history',[]))
    env._sim2real_precision_start=record['precision_start_reference_step']
    env.common_step_counter=record['common_step_counter']
    apply_live_curricula(env)


def apply_live_curricula(env):
    # Do not call competence review while restoring or assessing. Only replay
    # live range/weight schedules at the checkpoint's clock and ability stage.
    for term in env.cfg.curriculum.values():
        if term.func in (mdp.sim2real_guarded_curriculum,mdp.sim2real_precision_phase,mdp.push_curriculum):
            term.func(env,None,**term.params)


def precision_budget_remaining(env):
    start=env._sim2real_precision_start
    if start is None:return None
    used=(env.common_step_counter*env._sim2real_reference_factor-start)/24
    return max(0.,HEAD_BUDGET_REFERENCE_UPDATES-used)


def curriculum_snapshot(env):
    s=mdp.sim2real_state(env)
    return dict(stage=s['stage'],push_stage=s['push_stage'],balance_stage=s['balance_stage'],
        training_disturbance='four_direction_forces_and_velocity_additions_outside_balance_trials',
        velocity_push_ranges={name:env.event_manager.get_term_cfg(name).params['velocity_range']
            for name in ('push_robot','topple_push')if name in env.cfg.events},
        force_statistics_role='training_and_independent_force_assessment',
        balance_directions=['back','front','left','right'],
        balance_recent_trials=s['balance_window_counts'].sum(0).cpu().tolist(),
        balance_recent_rates=s['balance_rates'].cpu().tolist(),
        command_groups=['idle','straight','low','turn_negative','turn_positive','lateral','curve'],
        command_recent_trials=s['window_counts'].sum(0).cpu().tolist(),
        command_recent_rates=s['last_rates'].cpu().tolist(),
        push_directions=['back','front','left','right'],
        push_acceptance_groups=[f'{d}_{m}'for d in ('back','front','left','right')for m in ('pulse','sustained')],
        push_recent_trials=s['push_window_counts'].sum(0).cpu().tolist(),
        push_recent_rates=s['push_rates'].cpu().tolist(),
        **{k:s[k].cpu().tolist()for k in ('push_total_counts','push_total_wins',
           'push_total_truncated','push_total_seconds','push_total_impulse')})


def _evaluate_recovery_seed(task,policy,record,device,samples,seed):
    """Keep all simulator references within one seed's lifetime."""
    from mjlab.envs import ManagerBasedRlEnv
    from mjlab.tasks.registry import load_env_cfg,load_rl_cfg
    from .recovery import SC0090_RECOVERY_BUCKETS
    cfg=load_env_cfg(task);agent=load_rl_cfg(task)
    apply_checkpoint_recipe(cfg,agent,record,evaluation_num_envs=7*samples)
    cfg.seed=seed;cfg.auto_reset=False;cfg.episode_length_s=9.;cfg.terminations={}
    cfg.events={k:t for k,t in cfg.events.items()if t.mode!='interval'and k!='sim2real_balanced_push'}
    cfg.events['set_ground_state'].params['evaluation_buckets']=True
    for key in ('sim2real_competence','sim2real_push_magnitude','sim2real_topple_push'):
        cfg.curriculum.pop(key,None)
    env=ManagerBasedRlEnv(cfg,device=device)
    native=env.command_manager.compute
    try:
        restore_learning_state(env,record)
        def commands(dt):
            native(dt)
            for name in ('twist','head_pose','body_pose'):
                env.command_manager.get_command(name).zero_()
        env.command_manager.compute=commands
        obs,_=env.reset(seed=seed)
        state=mdp.sim2real_recovery_state(env)
        invalid=torch.zeros(env.num_envs,device=device,dtype=torch.bool)
        with torch.inference_mode():
            for _ in range(400):
                obs,*_=env.step(policy(obs))
                invalid|=~mdp.sim2real_state(env)['finite']
        metric=mdp.sim2real_state(env)
        success=(state.hold>=25)&~invalid&~metric['fallen']
        groups={}
        for i,name in enumerate(SC0090_RECOVERY_BUCKETS):
            mask=state.bucket==i
            groups[name]=dict(trials=int(mask.sum()),wins=int((mask&success).sum()))
        directions={}
        for name,sign in [('negative',-1),('positive',1)]:
            mask=(state.bucket==3)&(state.frontier_direction==sign)
            directions[name]=dict(trials=int(mask.sum()),wins=int((mask&success).sum()))
        return dict(seed=seed,finite=not bool(invalid.any()),groups=groups,
            frontier_directions=directions,head_tail_mae_rad=None,
            training_reference_factor=env._sim2real_reference_factor,
            com_range=env.event_manager.get_term_cfg('randomize_com').params['ranges'])
    finally:
        env.command_manager.compute=native
        env.close()


def evaluate_recovery(task,policy,record,device,samples=128,seeds=EVAL_SEEDS):
    """Frozen actor + normalizer; release each isolated simulator before the next."""
    if samples<2 or samples%2:raise ValueError('Even samples are needed for balanced roll signs')
    rng=capture_rng();training=policy.training
    frozen={k:v.detach().clone()for k,v in policy.state_dict().items()}
    cases=[];policy.eval()
    try:
        for seed in seeds:
            gc.collect();torch.cuda.empty_cache()
            try:cases.append(_evaluate_recovery_seed(task,policy,record,device,samples,seed))
            finally:
                gc.collect();torch.cuda.empty_cache()
        for k,v in policy.state_dict().items():
            if not torch.equal(v,frozen[k]):raise RuntimeError('Assessment changed actor/normalizer')
    finally:
        policy.train(training);restore_rng(rng)
    return cases


def assess_checkpoint(task,runner,path,samples=128):
    env=runner.env.unwrapped
    saved=torch.load(path,map_location='cpu',weights_only=False);record=saved['infos'][KEY]
    # A report is bound to the immutable actor file, configuration and frontier.
    request=dict(schema=2,checkpoint_sha256=hashlib.sha256(path.read_bytes()).hexdigest(),
        config_sha256=hashlib.sha256(json.dumps(dict(recipe=record['recipe_sha256'],
            batch=record['batch_contract'],geometry=record['geometry_sha256']),sort_keys=True).encode()).hexdigest(),
        iteration=record['completed_updates'],stage=record['recovery']['stage'],
        discovery=record['recovery']['discovery'],seeds=list(EVAL_SEEDS),
        samples_per_group=samples,duration_s=8.,deterministic=True)
    q=env.sim.data.qpos.clone();v=env.sim.data.qvel.clone()
    rng=capture_rng(env)
    report={**request,'cases':evaluate_recovery(task,runner.alg.get_policy(),record,runner.device,samples)}
    if not torch.equal(q,env.sim.data.qpos)or not torch.equal(v,env.sim.data.qvel):
        raise RuntimeError('Assessment changed live training physics')
    after=capture_rng(env)
    if not torch.equal(rng['cpu'],after['cpu'])or not torch.equal(rng['paired'],after['paired'])or any(
        not torch.equal(x,y)for x,y in zip(rng['cuda'],after['cuda'])):
        raise RuntimeError('Assessment changed training RNG')
    decision=mdp.sim2real_apply_recovery_evaluation(env,report,request)
    apply_live_curricula(env)
    return report,decision
