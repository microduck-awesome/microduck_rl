"""Native CPU replay of a compiled V2 world, using its actual sampled fields.

Only foot/plane collision generation is replaced by the pinned Warp adapter.
Other CPU contacts and numerical solver differences remain visible in reports.
"""
from copy import copy
from collections import deque
import mujoco
import numpy as np
from mjlab_microduck.actuator.mujoco import DofFrictionMujocoController
from mjlab_microduck.actuator.sc0090_v5 import load_v5_model
from mjlab_microduck.custom_v2.microduck_v2 import POLICY_JOINTS
from .cpu_warp_contacts import CpuWarpFootContacts


def rotation(q):
    matrix=np.empty(9);mujoco.mju_quat2Mat(matrix,np.asarray(q,dtype=np.float64))
    return matrix.reshape(3,3)


def snapshot_worlds(env):
    """Copy every expanded model field plus motor operating conditions."""
    fields={name:getattr(env.sim.model,name).detach().cpu().numpy().copy()
            for name in sorted(env.sim.expanded_fields)}
    nu=env.sim.mj_model.nu;n=env.num_envs
    motor={key:np.ones((n,nu))for key in ('kp','kd','vin','friction','electrical_kd')}
    motor.update({key:np.zeros((n,nu),dtype=np.int64)for key in ('delay_min_lag','delay_max_lag')})
    motor['encoder_bias']=np.zeros((n,nu))
    motor.update({key:np.zeros((n,nu))for key in ('drop_gain','supply_resistance','vin_min','supply_group')})
    motor.update({key:np.full((n,nu),np.inf)for key in ('max_current_a','effort_limit_nm')})
    for group,actuator in enumerate(env.scene['robot'].actuators):
        indices=[env.sim.mj_model.actuator('robot/'+name).id for name in actuator.target_names]
        for key,value in [('kp',actuator.cfg.kp_fw*actuator.kp_scale),
                          ('kd',actuator.cfg.kd_fw*actuator.firmware_kd_scale),
                          ('vin',actuator.vin_tensor),('friction',actuator.friction_scale),
                          ('electrical_kd',actuator.kd_scale)]:
            motor[key][:,indices]=value.detach().cpu().numpy()
        for key in ('delay_min_lag','delay_max_lag'):motor[key][:,indices]=getattr(actuator.cfg,key)
        motor['encoder_bias'][:,indices]=env.scene['robot'].data.encoder_bias[:,actuator.target_ids].cpu().numpy()
        if actuator.vin_drop_gain is not None:motor['drop_gain'][:,indices]=actuator.vin_drop_gain.cpu().numpy()
        if actuator.vin_drop_resistance is not None:motor['supply_resistance'][:,indices]=actuator.vin_drop_resistance.cpu().numpy()
        motor['vin_min'][:,indices]=actuator.cfg.vin_min or 0.
        motor['supply_group'][:,indices]=group
        for key,value in [('max_current_a',actuator._bam_model.actuator.max_current),
                          ('effort_limit_nm',actuator._bam_model.actuator.effort_limit_nm)]:
            if value is not None:motor[key][:,indices]=value
    return fields,motor


class CommandDelayReplay:
    """Apply the captured physical-step lag choices to this world's own targets."""
    def __init__(self,min_lags,max_lags):
        self.min_lags=np.asarray(min_lags,dtype=np.int64)
        self.max_lags=np.asarray(max_lags,dtype=np.int64)
        self.history=deque(maxlen=int(self.max_lags.max())+1)

    def apply(self,target,lags):
        lags=np.asarray(lags)
        if lags.shape!=self.max_lags.shape or not np.issubdtype(lags.dtype,np.integer):
            raise ValueError('One integer physics-step lag is required per actuator')
        if ((lags<self.min_lags)|(lags>self.max_lags)).any():
            raise ValueError('Command delay is outside the sampled training recipe')
        self.history.append(np.asarray(target).copy())
        available=np.asarray(self.history)
        rows=len(available)-1-np.minimum(lags,len(available)-1)
        return available[rows,np.arange(len(lags))]


class NativeBaseline:
    def __init__(self,source_model,fields,motor,world,qpos,qvel,origin,imu,limits):
        self.model=copy(source_model)
        for name,values in fields.items():
            target=getattr(self.model,name)
            target[:]=values[world].reshape(target.shape)
        self.data=mujoco.MjData(self.model);self.origin=origin;self.imu=rotation(imu)
        self.root=int(self.model.jnt_bodyid[0])
        self.joints=[self.model.joint('robot/'+name).id for name in POLICY_JOINTS]
        self.qids=self.model.jnt_qposadr[self.joints];self.vids=self.model.jnt_dofadr[self.joints]
        self.names=[self.model.actuator(i).name for i in range(self.model.nu)]
        all_joints={self.model.joint(i).name:i for i in range(self.model.njnt)}
        play=[all_joints.get('robot/passive_'+name.removeprefix('robot/')+'_backlash')for name in self.names]
        self.play_qids=np.array([0 if i is None else self.model.jnt_qposadr[i]for i in play])
        self.play_vids=np.array([0 if i is None else self.model.jnt_dofadr[i]for i in play])
        self.play_mask=np.array([0. if i is None else 1. for i in play])
        bam=load_v5_model();bam.actuator.kp=motor['kp'][world];bam.actuator.kd=motor['kd'][world]
        bam.actuator.vin=motor['vin'][world]
        bam.actuator.max_current=motor['max_current_a'][world]
        bam.actuator.effort_limit_nm=motor['effort_limit_nm'][world]
        original=bam.actuator.compute_torque
        electrical=motor['electrical_kd'][world]
        bam.actuator.electrical_kd_scale=electrical
        bam.actuator.compute_torque=lambda control,enabled,q,dq:original(control,enabled,q,dq*electrical)
        original_control=bam.actuator.compute_control
        self.previous_motor_torque=np.zeros(self.model.nu)
        self.previous_duty_cycle=np.zeros(self.model.nu)
        base_voltage=motor['vin'][world].copy();gains=motor['drop_gain'][world]
        resistances=motor['supply_resistance'][world]
        floors=motor['vin_min'][world];groups=motor['supply_group'][world]
        def control(target,q,dq,dt):
            voltage=base_voltage.copy()
            for group in np.unique(groups):
                selected=groups==group
                load=np.abs(self.previous_motor_torque[selected]).sum()
                current=max(0.,np.sum(self.previous_duty_cycle[selected]*self.previous_motor_torque[selected]/bam.kt.value))
                voltage[selected]=np.maximum(voltage[selected]-gains[selected]*load-resistances[selected]*current,floors[selected])
            bam.actuator.vin=voltage
            self.effective_voltage=voltage.copy()
            return original_control(target,q+self.data.qpos[self.play_qids]*self.play_mask,dq,dt)
        bam.actuator.compute_control=control
        sampled_armature=self.model.dof_armature.copy()
        self.controller=DofFrictionMujocoController(bam,self.names,self.model,self.data)
        # The CPU BAM constructor writes nominal inertia; restore the sampled DR.
        self.model.dof_armature[:]=sampled_armature
        mujoco.mj_setConst(self.model,self.data)
        self.friction_scale=motor['friction'][world]
        self.encoder_bias=motor['encoder_bias'][world]
        self.command_delay=CommandDelayReplay(motor['delay_min_lag'][world],motor['delay_max_lag'][world])
        self.contacts=CpuWarpFootContacts(self.model)
        self.policy_actuators=[self.names.index('robot/'+name)for name in POLICY_JOINTS]
        self.mouth=self.names.index('robot/mouth');self.limits=np.asarray(limits)
        self.feet=[self.model.geom('robot/'+side+'_foot_collision').id for side in ('left','right')]
        self.sites=[self.model.site('robot/'+side+'_foot').id for side in ('left','right')]
        self.ground={i for i in range(self.model.ngeom)if self.model.geom_type[i]==mujoco.mjtGeom.mjGEOM_PLANE}
        neck=self.model.body('robot/neck').id
        def in_neck(body):
            while body:
                if body==neck:return True
                body=int(self.model.body_parentid[body])
            return False
        self.head_geoms={i for i in range(self.model.ngeom)if in_neck(int(self.model.geom_bodyid[i]))}
        self.data.qpos[:]=qpos;self.data.qvel[:]=qvel
        self.controller.reset(self.data.qpos);self.controller.model.actuator.reset()
        self.controller.last_ts=self.data.time
        mujoco.mj_forward(self.model,self.data)

    def raw_observations(self):
        angular=self.data.cvel[self.root,:3]
        r=rotation(self.data.xquat[self.root])
        policy=self.policy_actuators
        return (self.imu@(r.T@angular),self.imu@(r.T@np.array([0.,0.,-1.])),
                self.data.qpos[self.qids]+self.data.qpos[self.play_qids[policy]]*self.play_mask[policy],
                self.data.qvel[self.vids]+self.data.qvel[self.play_vids[policy]]*self.play_mask[policy])

    def feet_diagnostics(self):
        force=np.zeros((2,3));moment=np.zeros((2,3));count=np.zeros(2,dtype=int)
        buffer=np.empty(6)
        for cid,c in enumerate(self.data.contact):
            for foot,g in enumerate(self.feet):
                if g not in c.geom or not any(int(x)in self.ground for x in c.geom):continue
                mujoco.mj_contactForce(self.model,self.data,cid,buffer)
                sign=1 if int(c.geom[1])==g else -1
                f=sign*c.frame.reshape(3,3).T@buffer[:3]
                torque=sign*c.frame.reshape(3,3).T@buffer[3:]
                force[foot]+=f;moment[foot]+=torque+np.cross(c.pos-self.data.site_xpos[self.sites[foot]],f)
                count[foot]+=1
        slip=[]
        for site in self.sites:
            mujoco.mj_objectVelocity(self.model,self.data,mujoco.mjtObj.mjOBJ_SITE,site,buffer,0)
            slip.append(buffer[3:].copy())
        return dict(foot_force=force,foot_moment=moment,foot_contact_count=count,foot_velocity=np.array(slip))

    def step(self,action,wrench=None,command_lags=None):
        target=np.zeros(self.model.nu)
        target[self.policy_actuators]=np.clip(action,self.limits[:,0],self.limits[:,1])-self.encoder_bias[self.policy_actuators]
        if command_lags is None:
            if self.command_delay.max_lags.any():
                raise ValueError('CPU replay requires the captured command delay schedule')
            command_lags=np.zeros((4,self.model.nu),dtype=np.int64)
        if np.shape(command_lags)!=(4,self.model.nu):raise ValueError('Expected four physics substeps')
        self.last_applied_targets=np.empty((4,self.model.nu))
        self.data.xfrc_applied[:]=0
        if wrench is not None:self.data.xfrc_applied[self.root,:3]=wrench
        for substep in range(4):
            applied=self.command_delay.apply(target,command_lags[substep])
            self.controller.q_target[:]=applied
            self.last_applied_targets[substep]=applied
            self.controller.update()
            self.previous_motor_torque[:]=self.data.ctrl[self.controller.act_indexes]
            self.previous_duty_cycle[:]=self.controller.model.actuator.duty_cycle
            self.model.dof_frictionloss[self.controller.dof_indexes]*=self.friction_scale
            mujoco.mj_step(self.model,self.data)
        diagnostics=self.feet_diagnostics()
        q=self.data.xquat[self.root];tilt=np.arccos(np.clip(1-2*(q[1]**2+q[2]**2),-1,1))
        diagnostics.update(qpos=self.data.qpos.copy(),qvel=self.data.qvel.copy(),
            height=float(self.data.xpos[self.root,2]-self.origin[2]),tilt=float(tilt))
        angular=self.data.cvel[self.root,:3]
        offset=self.data.subtree_com[self.root]-self.data.xpos[self.root]
        linear=self.data.cvel[self.root,3:]-np.cross(angular,offset)
        r=rotation(q)
        pairs=[set(map(int,c.geom))for c in self.data.contact]
        diagnostics.update(lin=r.T@linear,ang=r.T@angular,
            head_contact=any(bool(pair&self.ground)and bool(pair&self.head_geoms)for pair in pairs),
            self_contact=any(not bool(pair&self.ground)for pair in pairs))
        # Match the training observation boundary after the final forward.
        mujoco.mj_forward(self.model,self.data)
        return diagnostics

    def close(self):self.contacts.close()
