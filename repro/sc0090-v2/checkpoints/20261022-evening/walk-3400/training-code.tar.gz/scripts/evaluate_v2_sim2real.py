"""Frozen-policy behavior acceptance with shared training measurements."""
from pathlib import Path
from dataclasses import asdict
import argparse,json,hashlib,os,sys
import torch
from mjlab.tasks.registry import load_env_cfg,load_rl_cfg,load_runner_cls
from mjlab.envs import ManagerBasedRlEnv
from mjlab.rl import RslRlVecEnvWrapper
from mjlab.managers import EventTermCfg
from mjlab_microduck.custom_v2.sim2real import RISE_TASK,WALK_TASK
from mjlab_microduck.custom_v2.sim2real_learning import KEY,apply_checkpoint_recipe
from mjlab_microduck.custom_v2.assessment import (cases_for,duration_for,command_multiplier,
    summarize,walking_primary_metrics,walking_yaw_clearance_metrics,walking_roll_parking_metrics,apply_fixed_commands,verify_command_age,CRITERIA,PROTOCOL_VERSION,DT)
from mjlab_microduck.tasks import mdp


def main():
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('--skill',choices=['rise','walk'],required=True)
    parser.add_argument('--protocol',choices=['recovery','tilt','slow_push','fast_push','four_way_push','walking','straight','head'],required=True)
    parser.add_argument('--checkpoint',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--device',default='cuda:0');parser.add_argument('--seed',type=int,default=2026102102)
    parser.add_argument('--samples',type=int,default=8)
    parser.add_argument('--evaluation-profile',choices=['training','nominal','full'],default='training')
    a=parser.parse_args()
    if a.samples<1 or(a.protocol=='recovery'and a.skill!='rise'):raise ValueError('Invalid protocol/sample count')
    if a.protocol in ('walking','straight')and a.skill!='walk':raise ValueError('Walking protocol needs walking task')
    a.output.mkdir(parents=True,exist_ok=False);torch.set_num_threads(2);torch.cuda.set_device(a.device)
    task=RISE_TASK if a.skill=='rise'else WALK_TASK
    cases=cases_for(a.protocol);duration=duration_for(a.protocol);steps=round(duration/DT)
    cfg=load_env_cfg(task);agent=load_rl_cfg(task)
    record=torch.load(a.checkpoint,map_location='cpu',weights_only=False)['infos'][KEY]
    apply_checkpoint_recipe(cfg,agent,record,evaluation_num_envs=len(cases)*a.samples,evaluation_profile=a.evaluation_profile)
    cfg.seed=a.seed;cfg.auto_reset=False;cfg.terminations={};cfg.episode_length_s=duration+1.
    cfg.events={k:v for k,v in cfg.events.items()if v.mode!='interval'and k!='sim2real_balanced_push'}
    cfg.curriculum.pop('sim2real_competence',None)
    cfg.curriculum.pop('sim2real_push_magnitude',None)
    cfg.curriculum.pop('sim2real_topple_push',None)
    cfg.curriculum.pop('sim2real_disturbance',None)
    if a.protocol=='recovery':cfg.events['set_ground_state'].params['evaluation_buckets']=True
    else:
        key='set_ground_state'if a.skill=='rise'else 'sim2real_standing_reset'
        cfg.events[key]=EventTermCfg(func=mdp.sim2real_evaluation_reset,mode='reset')
    if 'push'in a.protocol:
        cfg.events['sim2real_eval_force']=EventTermCfg(func=mdp.sim2real_force_step,mode='step',params={'evaluation':True})
    initialize=cfg.events['sim2real_initialize'].func
    def init(env,env_ids=None,**kwargs):
        initialize(env,env_ids,**kwargs)
        env._sim2real_eval_pose_index=torch.tensor([env._sim2real_pose_rows_2d[c.get('pitch_deg',0),c.get('roll_deg',0)]for c in cases],device=env.device).repeat_interleave(a.samples)
        env._sim2real_eval_outward_rate=torch.tensor([c.get('outward_rate_rad_s',0.)for c in cases],device=env.device).repeat_interleave(a.samples)
        if 'push'in a.protocol:
            env._sim2real_eval_push={key:torch.tensor([c[key]for c in cases],device=env.device,
                dtype=torch.long if key in ('direction','mode')else torch.float32).repeat_interleave(a.samples)
                for key in ('direction','mode','peak','duration')}
    cfg.events['sim2real_initialize'].func=init
    (a.output/'resolved-config.json').write_text(json.dumps(dict(env=asdict(cfg),criteria=CRITERIA,protocol_version=PROTOCOL_VERSION),indent=2,default=str)+'\n')
    env=ManagerBasedRlEnv(cfg,device=a.device)
    try:
        agent.upload_model=False;wrapped=RslRlVecEnvWrapper(env,clip_actions=agent.clip_actions)
        runner=load_runner_cls(task)(wrapped,asdict(agent),None,a.device)
        runner.load(str(a.checkpoint),map_location=a.device)
        actor=runner.alg.get_policy().eval();frozen={k:v.clone()for k,v in actor.state_dict().items()}
        targets=torch.tensor([c.get('twist',[0.]*3)for c in cases],device=a.device).repeat_interleave(a.samples,0)
        heads=torch.tensor([c.get('head',[0.]*4)for c in cases],device=a.device).repeat_interleave(a.samples,0)
        desired=torch.zeros_like(targets);head=torch.zeros_like(heads)
        def commands(dt):
            apply_fixed_commands(env,desired,head)
        env.command_manager.compute=commands
        obs,_=env.reset(seed=a.seed)
        storage={};index=[0];reward=env.reward_manager.compute
        head_ids,_=env.scene['robot'].find_joints(('neck_pitch','head_pitch','head_yaw','head_roll'),preserve_order=True)
        foot_ids,_=env.scene['robot'].find_sites(('left_foot','right_foot'),preserve_order=True)
        yaw_ids,_=env.scene['robot'].find_joints(('left_hip_yaw','right_hip_yaw'),preserve_order=True)
        roll_ids,_=env.scene['robot'].find_joints(('left_hip_roll','right_hip_roll'),preserve_order=True)
        root_global=env.scene['robot'].indexing.body_ids[mdp.sim2real_state(env)['root_ids']]
        def record_metrics(dt):
            value=reward(dt);s=mdp.sim2real_measure(env)
            fields=('pitch','pitch_rate','roll','roll_rate','height','tilt','yaw','lin','ang','feet','head_contact',
                'self_contact','healthy','stable','quiet','finite','head_gate','previous_command','velocity_mean',
                'command_age','head_command_age','tracking_hold','leg_speed','balance_mean','settled','leg_limit_near')
            values={k:s[k]for k in fields}
            actual_force=env.sim.data.xfrc_applied[:,root_global,:3]
            torch._assert_async(((actual_force-s['force']).abs()<1e-7).all(),'Requested force differs from physics wrench')
            values.update(qpos=env.sim.data.qpos,qvel=env.sim.data.qvel,actor_observation=obs['actor'],
                raw_action=env.action_manager.action,continuous_target=env.action_manager.get_term('joint_pos')._processed_actions,
                applied_force=actual_force,head_command=env.command_manager.get_command('head_pose'),
                head_position=mdp.sim2real_joint_outputs(env)[0][:,head_ids])
            if a.skill=='walk':
                robot=env.scene['robot'];q=mdp.sim2real_joint_outputs(env)[0][:,yaw_ids]
                limits=robot.data.joint_pos_limits[:,yaw_ids]
                values['hip_yaw_limit_distance']=torch.minimum(q-limits[...,0],limits[...,1]-q)
                roll_q=mdp.sim2real_joint_outputs(env)[0][:,roll_ids]
                roll_limits=robot.data.joint_pos_limits[:,roll_ids]
                values['hip_roll_limit_distance']=torch.minimum(roll_q-roll_limits[...,0],roll_limits[...,1]-roll_q)
                values['foot_position']=robot.data.site_pos_w[:,foot_ids]
            if 'camera_energy'in s:values['camera_energy']=s['camera_energy']
            if not storage:storage.update({k:torch.empty((steps,*v.shape),dtype=v.dtype,device=v.device)for k,v in values.items()})
            for k,v in values.items():storage[k][index[0]].copy_(v)
            return value
        env.reward_manager.compute=record_metrics
        with torch.inference_mode():
            for step in range(steps):
                index[0]=step;factor=command_multiplier(step*DT,a.protocol)
                torch._assert_async((obs['actor'][:,48:51]==targets*factor).all(),'Twist command boundary mismatch')
                torch._assert_async((obs['actor'][:,51:55]==heads*factor).all(),'Head command boundary mismatch')
                next_factor=command_multiplier((step+1)*DT,a.protocol)
                desired.copy_(targets*next_factor);head.copy_(heads*next_factor)
                obs,*_=wrapped.step(actor(obs))
        for k,v in actor.state_dict().items():assert torch.equal(v,frozen[k]),k
        data={k:v.cpu()for k,v in storage.items()};torch.save(data,a.output/'traces.pt')
        verify_command_age(data)
        rows=summarize(data,cases,a.samples,a.protocol)
        report=dict(status='EVALUATED',protocol=a.protocol,protocol_version=PROTOCOL_VERSION,
            training_phase=record.get('training_phase','legacy_full'),evaluation_profile=a.evaluation_profile,
            effective_phase=getattr(env,'_sim2real_training_phase','legacy_full'),
            task=task,seed=a.seed,duration_s=duration,criteria=CRITERIA,records=rows,
            checkpoint_sha256=hashlib.sha256(a.checkpoint.read_bytes()).hexdigest(),recipe_sha256=record['recipe_sha256'],
            batch_contract=record['batch_contract'],restored_clock=record['common_step_counter'],
            diagnostic_controls=steps*env.num_envs,learning_updates=0,
            training_evaluation_body_criteria_equal=True,
            force_verified_against_physics=True,
            measurement_boundary='after_reward_before_reset/command; geometry lags5ms',
            signal_definitions=dict(velocity='training 0.5s EMA',standing_head='0.1s physical mean',moving_head='1s physical mean',
                settling='continuous0.5s in target band; command-specific transition origin'),
            scope='Frozen actor/normalizer; original paired DR; fixed commands and declared physical forces; no autoreset. EVALUATED is not a skill-pass claim.')
        report['deterministic']=True
        report['command_age_verified_against_actual_requests']=True
        if a.protocol=='walking':
            report['primary_motion']=walking_primary_metrics(data)
            report['hip_yaw_clearance']=walking_yaw_clearance_metrics(data)
            report['hip_roll_parking']=walking_roll_parking_metrics(data)
        # This is a disposable CUDA process. Native Warp/MuJoCo finalizers can
        # segfault AFTER all results have been saved. Complete asynchronous
        # work and commit the result before letting the process boundary reclaim
        # its context. Failed physics/sampling never reaches this success exit.
        torch.cuda.synchronize(a.device)
        path=a.output/'report.json';temporary=path.with_suffix('.tmp')
        with temporary.open('w')as stream:
            stream.write(json.dumps(report,indent=2,allow_nan=False)+'\n')
            stream.flush();os.fsync(stream.fileno())
        temporary.replace(path)
        (a.output/'completion.json').write_text(json.dumps(dict(status='COMPLETE',
            diagnostic_controls=steps*env.num_envs,learning_updates=0,
            exit_scope='isolated process; CUDA synchronized; atomic report committed'))+'\n')
        sys.stdout.flush();sys.stderr.flush()
        os._exit(0)
    finally:env.close()


if __name__=='__main__':main()
