"""Explicitly bounded baseline allocation with isolated recovery assessments.

Default mode is qualification (<=16 updates total, discarded weights). Formal
mode is for a separately authorized run, requires a matching finite preflight,
and always requires an explicit update budget. Never called automatically.
"""
import argparse,json,os,signal,subprocess,sys,threading,time,traceback
from dataclasses import asdict
from pathlib import Path
START=time.monotonic()


def write_json(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2,default=str,allow_nan=False)+'\n');tmp.replace(path)


def main():
    p=argparse.ArgumentParser(__doc__)
    p.add_argument('--skill',choices=['rise','walk'],required=True)
    p.add_argument('--device',required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--mode',choices=['qualification','formal'],default='qualification')
    p.add_argument('--num-envs',type=int,choices=[64,8192,16384,20480],default=64)
    p.add_argument('--updates',type=int,required=True)
    p.add_argument('--resume',type=Path);p.add_argument('--preflight',type=Path)
    p.add_argument('--training-phase',choices=['foundation','random025','random050_transport025','random050','random075_transport050','random100_transport050','random100','robust'])
    p.add_argument('--eval-samples',type=int,default=128)
    p.add_argument('--eval-reference-updates',type=int,default=100)
    p.add_argument('--verify-behavior',action='store_true',help='Exercise complete behavior reports in a bounded qualification')
    a=p.parse_args()
    if a.updates<1 or a.eval_reference_updates<1:raise ValueError('Positive explicit budgets required')
    if a.mode=='qualification' and a.updates>16:raise ValueError('Qualification budget is at most 16')
    if a.eval_samples<2 or a.eval_samples%2:raise ValueError('Evaluation samples must be even')
    if a.mode=='formal' and (a.eval_samples!=128 or a.eval_reference_updates!=100 or a.num_envs==64):
        raise ValueError('Formal assessment is fixed: 2 seeds x 128/group every 100 reference updates')
    import torch
    from mjlab.envs import ManagerBasedRlEnv
    from mjlab.rl import RslRlVecEnvWrapper
    from mjlab.tasks.registry import load_env_cfg,load_rl_cfg,load_runner_cls
    from mjlab_microduck.custom_v2.sim2real import RISE_TASK,WALK_TASK,configure_batch_size
    from mjlab_microduck.custom_v2.sim2real_learning import (
        KEY,apply_checkpoint_recipe,assess_checkpoint,apply_walking_assessments,EVAL_SEEDS,
        precision_budget_remaining,recipe_sha256,curriculum_snapshot,WalkingLimitGuard)
    from mjlab_microduck.tasks import mdp
    torch.set_num_threads(2);torch.cuda.set_device(a.device)
    task=RISE_TASK if a.skill=='rise'else WALK_TASK
    from mjlab_microduck.custom_v2.training_phases import configure_phase,phase_promotable
    from mjlab_microduck.custom_v2.sim2real_learning import checkpoint_record
    record=torch.load(a.resume,map_location='cpu',weights_only=False)['infos'][KEY]if a.resume else None
    phase=record.get('training_phase','legacy_full')if record else(a.training_phase or 'foundation')
    if a.training_phase is not None and a.training_phase!=phase:raise ValueError('Use an explicit stage transition before changing phase')
    if a.mode=='formal':
        if a.preflight is None:raise ValueError('Matching bounded preflight report required')
        proof=json.loads(a.preflight.read_text())
        if (proof.get('status')!='PASS' or proof.get('task')!=task or
            proof.get('num_envs')!=a.num_envs or proof.get('recipe_sha256')!=recipe_sha256()or proof.get('training_phase')!=phase):
            raise ValueError('Preflight task/batch/source mismatch')
    cfg=load_env_cfg(task);agent=load_rl_cfg(task)
    cfg.seed=20261021;agent.seed=cfg.seed;agent.logger='tensorboard';agent.upload_model=False
    if a.resume:
        if record['batch_contract']['num_envs']!=a.num_envs:raise ValueError('Resume batch mismatch')
        if record['allocation_kind']!=a.mode:raise ValueError('Do not mix qualification and formal policies')
        contract=apply_checkpoint_recipe(cfg,agent,record)
    else:
        configure_phase(cfg,phase)
        contract=configure_batch_size(cfg,agent,a.num_envs)
    a.output.mkdir(parents=True,exist_ok=False)
    write_json(a.output/'allocation.json',dict(arguments=vars(a),task=task,batch_contract=contract,
        recipe_sha256=recipe_sha256(),training_phase=phase,env=asdict(cfg),agent=asdict(agent),
        purpose='finite verification; discard weights'if a.mode=='qualification'else 'authorized bounded fresh baseline experiment'))
    stopping=[False]
    for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,lambda *_:stopping.__setitem__(0,True))
    gpu=[];stop=threading.Event();timings=[]
    def monitor():
        while not stop.is_set():
            try:
                line=subprocess.check_output(['nvidia-smi','-i',a.device.split(':')[-1],
                    '--query-gpu=utilization.gpu,memory.used','--format=csv,noheader,nounits'],text=True,timeout=5)
                util,mem=map(float,line.strip().split(','));gpu.append(dict(elapsed_s=time.monotonic()-START,utilization_percent=util,memory_MiB=mem))
            except (subprocess.SubprocessError,ValueError):pass
            stop.wait(1)
    thread=threading.Thread(target=monitor,daemon=True);thread.start();env=None
    try:
        env=ManagerBasedRlEnv(cfg,device=a.device)
        runner=load_runner_cls(task)(RslRlVecEnvWrapper(env,clip_actions=agent.clip_actions),asdict(agent),str(a.output),a.device)
        runner.allocation_kind=a.mode;runner.managed_curriculum=True
        if a.resume:runner.load(str(a.resume),map_location=a.device)
        initial=runner.completed_updates;target=initial+a.updates
        if a.resume is None:
            counts={f'{name}/{key}':int(value.item())for name,model in
                (('actor',runner.alg.actor),('critic',runner.alg.critic))
                for key,value in model.state_dict().items()if key.endswith('obs_normalizer.count')}
            assert not any(counts.values())and not runner.alg.optimizer.state
            assert initial==0 and env.common_step_counter==0
            runner.save(str(a.output/'initial-0.pt'))
            write_json(a.output/'initialization.json',dict(fresh=True,qualification_weights_inherited=False,
                normalizer_counts=counts,optimizer_state_entries=0,completed_updates=0,common_step_counter=0))
        limit_guard=WalkingLimitGuard()if a.skill=='walk'else None
        limit_report={}
        if a.mode=='qualification' and target>16:raise ValueError('Resume cannot extend qualification beyond 16 total updates')
        native_log=runner.logger.log
        def log(*args,**kwargs):
            nonlocal limit_report
            timings.append(dict(completed_updates=runner.completed_updates,collection_s=kwargs['collect_time'],
                learning_s=kwargs['learn_time'],elapsed_s=time.monotonic()-START))
            native_log(*args,**kwargs)
            if limit_guard is not None:
                with torch.no_grad():
                    s=mdp.sim2real_measure(env)
                    valid=s['healthy']&(s['command_age']>=25)
                    enough=int(valid.sum())>=min(256,max(1,env.num_envs//4))
                    rates=(mdp.sim2real_leg_limit_mask(env)[valid].float().mean(0).cpu().tolist()if enough else None)
                limit_report=limit_guard.observe(rates,runner.completed_updates)
            write_json(a.output/'status.json',dict(status='RUNNING',mode=a.mode,pid=os.getpid(),
                completed_updates=runner.completed_updates,target_updates=target,common_step_counter=env.common_step_counter,
                curriculum=curriculum_snapshot(env),joint_limit_guard=limit_report))
        runner.logger.log=log
        interval=max(1,round(a.eval_reference_updates/env._sim2real_reference_factor))
        reason='explicit_budget'
        behavior_interval=max(1,round(400/env._sim2real_reference_factor))
        def behavior(protocol,path,iteration,samples,profile='training',seed=EVAL_SEEDS[0]):
            evaluator=Path(__file__).with_name('evaluate_v2_sim2real.py')
            prefix=''if profile=='training'else profile+'-'
            suffix=''if seed==EVAL_SEEDS[0]else f'-seed{seed}'
            destination=a.output/f'{prefix}{protocol}-assessment-{iteration}{suffix}'
            if not (destination/'completion.json').exists():
                with destination.with_suffix('.log').open('w')as log_file:
                    subprocess.run([sys.executable,str(evaluator),'--skill',a.skill,'--protocol',protocol,
                        '--checkpoint',str(path),'--device',a.device,'--samples',str(samples),'--seed',str(seed),
                        '--evaluation-profile',profile,
                        '--output',str(destination)],stdout=log_file,stderr=subprocess.STDOUT,check=True)
            return json.loads((destination/'report.json').read_text())
        while runner.completed_updates<target and not stopping[0]:
            amount=min(target-runner.completed_updates,interval-runner.completed_updates%interval)
            remaining=precision_budget_remaining(env)
            if remaining is not None:
                amount=min(amount,int(remaining/env._sim2real_reference_factor))
                if amount<1:reason='head_precision_budget_review';break
            runner.learn(amount,init_at_random_ep_len=False)
            iteration=runner.completed_updates
            if limit_report.get('rejected'):
                reason='persistent_joint_limit_parking_rollback_required'
                runner.save(str(a.output/f'quarantined-{iteration}.pt'))
                write_json(a.output/'rollback-required.json',dict(**limit_report,
                    completed_updates=iteration,reason=reason,quarantined_checkpoint=f'quarantined-{iteration}.pt'))
                break
            path=a.output/f'assessed-{iteration}.pt';runner.save(str(path))
            if limit_guard is not None and limit_report.get('checkpoint_candidate_safe'):
                limit_guard.last_healthy_checkpoint=str(path)
            if a.skill=='rise':
                report,decision=assess_checkpoint(task,runner,path,a.eval_samples)
                write_json(a.output/f'assessment-{iteration}.json',dict(report=report,decision=decision))
            # Preserve completed PPO and its curriculum decision before a
            # diagnostic subprocess can fail, for both skills. The assessed
            # file remains immutable.
            runner.save(str(a.output/'resume.pt'))
            if a.skill=='rise'and decision['polish']:
                behavior('head',path,iteration,32 if a.mode=='formal'else 2)
            phase_complete=a.mode=='formal'and phase!='robust'and phase_promotable(checkpoint_record(env))
            behavior_due=(iteration//behavior_interval>(iteration-amount)//behavior_interval or iteration==target
                          or phase_complete or precision_budget_remaining(env)==0)
            if (a.mode=='formal'and behavior_due)or a.verify_behavior:
                samples=32 if a.mode=='formal'else 2
                protocols=(('walking','straight','four_way_push')if a.skill=='walk'else('tilt','four_way_push','head'))if phase=='robust'else(('walking','straight')if a.skill=='walk'else('tilt',))
                reports={protocol:behavior(protocol,path,iteration,samples)for protocol in protocols}
                if a.skill=='walk':
                    second=behavior('walking',path,iteration,samples,seed=EVAL_SEEDS[1])
                    import hashlib
                    decision=apply_walking_assessments(env,[reports['walking'],second],hashlib.sha256(path.read_bytes()).hexdigest())
                    write_json(a.output/f'primary-motion-{iteration}.json',decision)
                    if a.mode=='formal'and a.resume is not None and phase!='foundation'and all(
                        case['survival']['never_fell']<.5*case['survival']['trials']
                        for case in decision['cases']):
                        # The admitted pretrained policy survives this envelope.
                        # Two-seed collapse after continuation is regression,
                        # not a fresh policy needing a longer discovery budget.
                        reason='cold_home_regression_rollback_required'
                        runner.save(str(a.output/f'quarantined-{iteration}.pt'))
                        write_json(a.output/'rollback-required.json',dict(reason=reason,
                            completed_updates=iteration,assessment=decision))
                        break
                    phase_complete=a.mode=='formal'and phase!='robust'and phase_promotable(checkpoint_record(env))
                    if decision.get('sustained_yaw_parking')or decision.get('sustained_idle_roll_parking'):
                        reason=('persistent_idle_roll_parking_rollback_required'if decision.get('sustained_idle_roll_parking')else'persistent_yaw_limit_parking_rollback_required')
                        runner.save(str(a.output/f'quarantined-{iteration}.pt'))
                        write_json(a.output/'rollback-required.json',dict(reason=reason,completed_updates=iteration,
                            source='frozen two-seed physical assessment; conditional parking is not diluted across commands',
                            assessment=decision))
                        break
            if a.mode=='formal'and(iteration==target or phase_complete)and phase!='robust':
                if a.skill=='rise':
                    shadow,_=assess_checkpoint(task,runner,path,a.eval_samples,evaluation_profile='full',apply_decision=False)
                    write_json(a.output/f'full-assessment-{iteration}.json',dict(report=shadow,decision=None))
                else:behavior('walking',path,iteration,32,profile='full')
            # Leave the assessed file immutable; continuation includes the decision.
            runner.save(str(a.output/'resume.pt'))
            if phase_complete:
                reason='walking_yaw_clearance'if a.skill=='walk'else 'primary_motion_mastery'
                break
        if stopping[0]:reason='signal'
        if not limit_report.get('rejected'):runner.save(str(a.output/'resume.pt'))
        stop.set();thread.join(timeout=6)
        write_json(a.output/'gpu-samples.json',gpu)
        write_json(a.output/'timing.json',timings)
        write_json(a.output/'status.json',dict(status='BOUNDED_COMPLETE',mode=a.mode,reason=reason,
            completed_updates=runner.completed_updates,updates_this_allocation=runner.completed_updates-initial,
            new_formal_updates=runner.completed_updates-initial if a.mode=='formal'else 0,
            whole_process_wall_s=time.monotonic()-START,task=task,recipe_sha256=recipe_sha256(),joint_limit_guard=limit_report))
    except BaseException:
        write_json(a.output/'status.json',dict(status='FAILED',error=traceback.format_exc(),mode=a.mode));raise
    finally:
        stop.set();thread.join(timeout=6)
        if env is not None:env.close()


if __name__=='__main__':main()
