"""Fresh baseline environments grounded in October 21 hardware results.

No P04 runtime, teachers, continuation, count targets, or action EMA.
Command transport delay is separate from the frozen v5 internal motor law.
Both skills share measured mass and CAD, with task-specific contact profiles.
"""
from copy import deepcopy
from dataclasses import replace
from pathlib import Path
import hashlib,json,re,math
import mujoco,torch
from mjlab.managers import EventTermCfg,RewardTermCfg,CurriculumTermCfg,MetricsTermCfg,SceneEntityCfg
from mjlab.envs.mdp import dr
from mjlab.sensor import ContactMatch,ContactSensorCfg
from . import microduck_v2 as v2
from . import paired_randomization
from .commands import BalancedHeadCommandCfg
from mjlab_microduck.tasks import mdp

RISE_TASK='Mjlab-StandUp-Flat-MicroDuck-V2-Sim2real-Baseline-20261021'
WALK_TASK='Mjlab-Velocity-Flat-MicroDuck-V2-Sim2real-Baseline-20261021'
ROOT=Path(__file__).resolve().parents[3]
DEPLOYMENT=ROOT/'docs/hardware-handoff/deployment/D747A9-20261021.json'
MODEL=v2.ASSETS/'robot_sim2real.xml'  # Preserved first-review geometry, not a live task.
SOURCE_MODELS={kind:v2.ASSETS/f'robot_sim2real_{kind}.xml' for kind in ('rise','walk')}
MODELS={kind:v2.ASSETS/f'robot_sim2real_{kind}_backlash.xml' for kind in ('rise','walk')}
HEAD_COM_BODIES=('neck','neck_pitch','yaw_roll_motion','bottom_head_shell','jaw_soft')
ENCODER_BIAS_RAD=math.radians(2.)
RANDOMIZATION_CONTRACT=dict(
    command_transport_delay_ms=[10,15,20,25],command_delay_update='each_5ms_physics_step',
    command_delay_sampling='uniform_per_world_per_actuator_group',
    joint_friction_scale=[.9,1.1],joint_armature_scale=[.9,1.1],
    encoder_bias_rad=[-ENCODER_BIAS_RAD,ENCODER_BIAS_RAD],encoder_bias_lifetime='whole_run_per_joint_per_world',
    encoder_bias_basis='user_requested_2deg_robustness_range_not_measured_distribution',
    encoder_bias_application='observation_plus_b;physical_target_clipped_action_minus_b',
    head_com_bodies=list(HEAD_COM_BODIES),voltage_uniform_v=[10.2,12.4],
    supply_resistance_uniform_ohm=[.05,.15],voltage_floor_v=9.,
    supply_sampling='startup_fixed_across_resets;one_common_3s_bus',
    supply_load='max(0,sum(previous_duty*previous_motor_torque/kt));all_15_servos',
    supply_resistance_basis='engineering_training_prior_0.2_to_0.6V_at_4A_not_measured',
    battery='user_confirmed_GNB_2000mAh_3S_5C',
    supply_base='quiescent_bus_voltage_including_electronics;no_double_count_idle_load',
    supply_regeneration='offset_shared_load_only;no_bus_overvoltage_model',
    paired_error_retained=True,extra_joint_white_noise=False,
    explicit_backlash=True,backlash_total_width_deg=2.,backlash_source='official_v8_training_assumption',
    load_voltage_sag=True,terrain='plane',
    max_pwm=1.,max_current_a=.6,current_cap_basis='SC0090_0.6A_stall_reference_training_prior_not_measured_limiter',
    ctrl_limited=True,force_limited=True,
    effort_limit_formula='min(V_range_max*max_pwm*kt/R_motor,max_current*kt);symmetric_Nm_all_15',
    disturbances='regular_walk_0.3mps;regular_rise_0_0.08_0.3_at_0_500_1000_reference_updates;3-6s;user_retained_topple_4-8s_0.3_0.6_0.9_1.2_at_0_100_400_800;velocity_pushes_outside_balance_trials',
    balance_initial_angles_deg=[2,5,10],balance_outward_rates_rad_s=[0.,.1,.3],
    balance_directions=['back','front','left','right'],balance_band_deg=4.,
    force_peaks_N=[.25,.45,.7],force_pulse_s=[.24,.40],force_sustained_s=[1.2,2.0])


def configure_randomization(cfg):
    """Current V2 tasks only; retain historical baseline/P04 identities."""
    robot=cfg.scene.entities['robot']
    # One electrical group: the 3S battery directly supplies all 15 servos.
    # Actions still address only the named 14 policy joints; mouth holds separately.
    robot.articulation.actuators=(replace(robot.articulation.actuators[0],
        target_names_expr=(*v2.POLICY_JOINTS,'mouth'),command_transport_delay=True,
        delay_min_lag=2,delay_max_lag=5,delay_update_period=0,delay_hold_prob=0.,
        randomized_supply=True,vin_range=(10.2,12.4),vin_drop_gain_range=None,
        supply_resistance_range=(.05,.15),vin_min=9.,
        encoder_through_backlash=True,max_current_a=.6,official_effort_clamps=True),)
    cfg.events['randomize_head_com'].params['asset_cfg']=SceneEntityCfg(
        'robot',body_names=HEAD_COM_BODIES)
    cfg.events['randomize_joint_friction']=EventTermCfg(
        func=mdp.sim2real_randomize_motor_friction,mode='reset',params={'scale_range':(.9,1.1)})
    cfg.events['randomize_armature']=EventTermCfg(func=dr.joint_armature,mode='reset',
        params={'asset_cfg':SceneEntityCfg('robot',joint_names=(*v2.POLICY_JOINTS,'mouth')),
                'operation':'scale','ranges':(.9,1.1)})
    cfg.events['encoder_bias']=EventTermCfg(func=dr.encoder_bias,mode='startup',
        params={'asset_cfg':SceneEntityCfg('robot',joint_names=v2.POLICY_JOINTS,preserve_order=True),
                'bias_range':(-ENCODER_BIAS_RAD,ENCODER_BIAS_RAD)})
    cfg.observations['actor'].terms['joint_pos'].func=mdp.sim2real_proxy_joint_pos
    cfg.observations['actor'].terms['joint_vel'].func=mdp.sim2real_proxy_joint_vel
    for name,func in [('joint_pos',mdp.joint_pos_rel_backlash),('joint_vel',mdp.joint_vel_rel_backlash)]:
        cfg.observations['critic'].terms[name].func=func
    # Keep paired sensor errors; the old reset must not overwrite continuous
    # startup voltage with its historical three-point sampler.
    cfg.events['paired_error_reset'].func=mdp.sim2real_reset_error_blocks
    if 'pose'in cfg.rewards:cfg.rewards['pose'].func=mdp.sim2real_variable_posture
    return cfg

def model_path(kind,training_phase='legacy_full'):
    if training_phase!='legacy_full':
        from .training_phases import phase_model_path
        return phase_model_path(kind,training_phase)
    return MODELS[kind]

def rise_spec():return mujoco.MjSpec.from_file(str(model_path('rise')))
def walk_spec():return mujoco.MjSpec.from_file(str(model_path('walk')))

def install_normal_observation_buffers():
    """Scope mjlab history-buffer allocations to normal tensors for these tasks.

    Mjlab replaces stochastic-delay tensors inside inference-mode collection;
    ordinary reset then cannot modify them. No arithmetic/RNG or history timing
    changes: only the buffer lifetime type. Class methods retain correct shadow
    manager binding during terminal-critic capture.
    """
    from functools import wraps
    from mjlab.managers.observation_manager import ObservationManager
    for name in ('compute','compute_group'):
        native=getattr(ObservationManager,name)
        if getattr(native,'_sim2real_normal_buffers',False):continue
        def decorate(original):
            @wraps(original)
            def call(self,*args,**kwargs):
                if not hasattr(self._env,'_sim2real_kind'):
                    return original(self,*args,**kwargs)
                with torch.inference_mode(False),torch.no_grad():
                    return original(self,*args,**kwargs)
            call._sim2real_normal_buffers=True
            return call
        setattr(ObservationManager,name,decorate(native))


def configure_batch_size(cfg,agent,num_envs):
    """Scale learning exposure, not physical time, from the 8192 baseline.

    Keep 49,152 samples per minibatch for actual-N runs and five visits/sample.
    Inherited step curricula use reference control transitions; episode duration,
    sensor delays and force lifetimes stay in seconds and are never rescaled.
    """
    if num_envs not in (64,8192,16384,20480,24576):raise ValueError('Unqualified environment count')
    if hasattr(cfg,'_sim2real_batch_contract'):raise ValueError('Select batch size once on a fresh config')
    phase=cfg.events['sim2real_initialize'].params.get('training_phase','foundation')
    if cfg.events['sim2real_initialize'].params['kind']=='walk'and phase!='foundation':
        agent.algorithm.entropy_coef=.001
    factor=max(1.,num_envs/8192)
    for term in cfg.curriculum.values():
        for stages in term.params.values():
            if isinstance(stages,list):
                for stage in stages:
                    if isinstance(stage,dict)and'step'in stage:
                        stage['step']=round(stage['step']/factor)
    cfg.scene.num_envs=num_envs
    agent.algorithm.num_mini_batches=4 if num_envs==64 else 4*num_envs//8192
    contract=dict(reference_envs=8192,num_envs=num_envs,rollout_steps=24,
                  minibatches=agent.algorithm.num_mini_batches,samples_per_minibatch=num_envs*24//agent.algorithm.num_mini_batches,
                  epochs=5,reference_learning_step_factor=factor,physical_time_unchanged=True)
    cfg._sim2real_batch_contract=contract
    cfg.events['sim2real_initialize'].params.update(
        reference_factor=factor,training_num_envs=num_envs)
    return contract


def initialize(env,env_ids=None,kind='rise',reference_factor=1.,training_num_envs=8192,
               training_phase='legacy_full',evaluation_profile='training'):
    env._sim2real_kind=kind
    env._sim2real_reference_factor=reference_factor
    env._sim2real_training_num_envs=training_num_envs
    env._sim2real_training_phase=training_phase
    env._sim2real_evaluation_profile=evaluation_profile
    env._sim2real_precision_start=None
    install_normal_observation_buffers()
    assert abs(env.sim.mj_model.body_mass.sum()-.6246)<1e-10
    assert not hasattr(env,'_v2_joint_feedback')
    assert env.cfg.actions['joint_pos'].__class__.__name__=='JointPositionActionCfg'
    assert env.cfg.actions['joint_pos'].scale==1.
    bank=json.loads((v2.ASSETS/'sim2real_balance_poses.json').read_text())
    source=mujoco.MjModel.from_xml_path(str(SOURCE_MODELS[kind]))
    target=mujoco.MjModel.from_xml_path(str(model_path(kind,training_phase)))
    with torch.inference_mode(False):
        original=torch.tensor([p['qpos']for p in bank['poses']],device=env.device)
        expanded=torch.zeros((len(bank['poses']),target.nq),device=env.device)
        expanded[:,:7]=original[:,:7]
        velocity=torch.tensor([p['outward_unit_qvel']for p in bank['poses']],device=env.device)
        expanded_velocity=torch.zeros((len(bank['poses']),target.nv),device=env.device)
        expanded_velocity[:,:6]=velocity[:,:6]
        for name in (*v2.POLICY_JOINTS,'mouth'):
            expanded[:,int(target.joint(name).qposadr[0])]=original[:,int(source.joint(name).qposadr[0])]
            expanded_velocity[:,int(target.joint(name).dofadr[0])]=velocity[:,int(source.joint(name).dofadr[0])]
        env._sim2real_pose_bank=expanded
        env._sim2real_pose_velocity=expanded_velocity
    env._sim2real_pose_rows={p['pitch_deg']:i for i,p in enumerate(bank['poses'])if p['roll_deg']==0}
    env._sim2real_pose_rows_2d={(p['pitch_deg'],p['roll_deg']):i for i,p in enumerate(bank['poses'])}
    mdp.sim2real_state(env)
    if kind=='rise':mdp.sim2real_recovery_state(env)
    from .error_proxy import proxy_state
    with torch.inference_mode(False):
        state=proxy_state(env,str(paired_randomization.BANK))
        first=env.scene['robot'].actuators[0]
        assert len(env.scene['robot'].actuators)==1,'All 15 servos must share one electrical bus'
        state.robot_voltage=first.vin_tensor[:,0]


def common(cfg,kind):
    configure_randomization(cfg)
    robot=cfg.scene.entities['robot'];robot.spec_fn=rise_spec if kind=='rise' else walk_spec
    model=robot.spec_fn().compile()
    # Keep exact CAD collision masks instead of generic named-geom overrides.
    for collision in robot.collisions:
        names=[model.geom(i).name for i in range(model.ngeom)if any(re.fullmatch(p,model.geom(i).name)for p in collision.geom_names_expr)]
        for field in ('contype','conaffinity','condim'):
            setattr(collision,field,{'^'+re.escape(n)+'$':int(getattr(model.geom(n),field)[0])for n in names})
    cfg.scene.num_envs=8192;cfg.sim.mujoco.timestep=.005;cfg.decimation=4
    cfg.sim.mujoco.iterations=30 if kind=='rise' else 10
    cfg.sim.mujoco.ls_iterations=50 if kind=='rise' else 20
    cfg.sim.nconmax=128 if kind=='rise' else 64
    deployment=json.loads(DEPLOYMENT.read_text())
    limits={x['name']:tuple(x['servo_target_rad_range'])for x in deployment['limits']['per_joint']}
    cfg.actions['joint_pos'].clip={n:limits[n]for n in v2.POLICY_JOINTS}
    # Sensor subtree includes neck, main shell and independently actuated mouth.
    cfg.scene.sensors=(*cfg.scene.sensors,
      ContactSensorCfg(name='sim2real_head_ground',primary=ContactMatch(mode='subtree',pattern='neck',entity='robot'),secondary=ContactMatch(mode='body',pattern='terrain'),fields=('found','force'),reduce='netforce',num_slots=1),
      ContactSensorCfg(name='sim2real_jaw_ground',primary=ContactMatch(mode='body',pattern='jaw_soft',entity='robot'),secondary=ContactMatch(mode='body',pattern='terrain'),fields=('found','force'),reduce='netforce',num_slots=1))
    if kind=='rise':
        cfg.scene.sensors=(*cfg.scene.sensors,
          ContactSensorCfg(name='sim2real_shell_ground',primary=ContactMatch(mode='geom',pattern='sim2real_shell_.*_collision',entity='robot'),secondary=ContactMatch(mode='body',pattern='terrain'),fields=('found','force'),reduce='netforce',num_slots=1))
    cfg.events={'sim2real_reset_metrics':EventTermCfg(func=mdp.sim2real_reset_metrics,mode='reset'),**cfg.events}
    cfg.events['sim2real_initialize']=EventTermCfg(func=initialize,mode='startup',params={'kind':kind})
    initial_push=0. if kind=='rise' else .3
    cfg.events['sim2real_balanced_push']=EventTermCfg(func=mdp.sim2real_force_step,mode='step')
    cfg.events['push_robot']=EventTermCfg(func=mdp.sim2real_velocity_push,mode='interval',
        interval_range_s=(3.,6.),params={'velocity_range':{
            'x':(-initial_push,initial_push),'y':(-initial_push,initial_push)}})
    # Explicit user choice: retain VelStand-derived topple augmentation in both
    # standalone skills, independently of when the combined skill is trained.
    cfg.events['topple_push']=EventTermCfg(func=mdp.sim2real_velocity_push,mode='interval',
        interval_range_s=(4.,8.),params={'velocity_range':{'x':(-.3,.3),'y':(-.3,.3)}})
    cfg.curriculum['sim2real_topple_push']=CurriculumTermCfg(func=mdp.push_curriculum,
        params={'event_name':'topple_push','push_stages':[
            {'step':i*24,'velocity_range':{'x':(-v,v),'y':(-v,v)}}
            for i,v in [(0,.3),(100,.6),(400,.9),(800,1.2)]]})
    cfg.curriculum.pop('push_magnitude',None)
    if kind=='rise':
        cfg.curriculum['sim2real_push_magnitude']=CurriculumTermCfg(func=mdp.push_curriculum,
            params={'event_name':'push_robot','push_stages':[
                {'step':i*24,'velocity_range':{'x':(-v,v),'y':(-v,v)}}
                for i,v in [(0,0.),(500,.08),(1000,.3)]]})
    cfg.curriculum['sim2real_competence']=CurriculumTermCfg(func=mdp.sim2real_curriculum)
    cfg.rewards['head_pose_tracking'].func=mdp.sim2real_head_tracking
    cfg.rewards['head_pose_bias'].func=mdp.sim2real_head_bias
    cfg.rewards['balance_quality']=RewardTermCfg(func=mdp.sim2real_balance_quality,weight=1.)
    cfg.rewards['outward_tilt']=RewardTermCfg(func=mdp.sim2real_outward_tilt_cost,weight=-.3)
    cfg.rewards['balance_fall']=RewardTermCfg(func=mdp.sim2real_balance_fall_cost,weight=-1.)
    cfg.metrics['sim2real_camera']=MetricsTermCfg(func=mdp.sim2real_camera_sample,per_substep=True)
    guard_curricula(cfg)
    return cfg


def guard_curricula(cfg):
    rules={mdp.reward_weight:'weight',mdp.com_range_curriculum:'com',
           mdp.pose_command_range_curriculum:'command'}
    for term in cfg.curriculum.values():
        if term.func in rules:
            term.params['rule']=rules[term.func]
            term.func=mdp.sim2real_guarded_curriculum


def rise_cfg(play=False):
    from .training import make_standup_env_cfg
    cfg=paired_randomization.configure(make_standup_env_cfg(play))
    cfg=common(cfg,'rise')
    cfg.events['set_ground_state'].func=mdp.sim2real_reset_recovery
    cfg.rewards['stable_standing'].func=mdp.sim2real_stable_standing
    cfg.curriculum['sim2real_precision']=CurriculumTermCfg(func=mdp.sim2real_precision_phase)
    # No new head-ground penalty/termination during physical recovery.
    return cfg


def walk_cfg(play=False):
    from .training import _replace_standing_height
    cfg=paired_randomization.configure(v2.make_v2_baseline_env_cfg(play))
    cfg=common(cfg,'walk')
    cfg.commands['head_pose']=BalancedHeadCommandCfg(**vars(cfg.commands['head_pose']))
    # A_fresh and all successful V2 walking recipes explicitly sampled HOME.
    # Uniform active head requests do not expose the exact deployment idle.
    cfg.commands['head_pose'].zero_command_prob=.5
    cfg.rewards['head_pose_tracking'].params['deadband_rad']=mdp.SIM2REAL_HEAD_POSITION_BAND
    # Historical Head1 keeps a broad gradient while adding a useful local
    # signal. Current HOME yaw error~11.5deg is too large for micro precision.
    # Only stationary requests use this intermediate scale; moving head
    # tracking retains its broad kernel and1s mean-bias objective.
    cfg.rewards['standing_head_coarse']=RewardTermCfg(
        func=mdp.sim2real_standing_head_coarse,weight=1.,
        params={'std':.15,'deadband_rad':mdp.SIM2REAL_HEAD_POSITION_BAND})
    cmd=vars(cfg.commands['twist']).copy();cmd.update(heading_command=False,rel_heading_envs=0.,rel_world_envs=0.,rel_forward_envs=0.,rel_turn_in_place_envs=0.,rel_standing_envs=0.,debug_vis=False,resampling_time_range=(3.,8.))
    cmd['ranges']=deepcopy(cmd['ranges']);cmd['ranges'].heading=None
    cfg.commands['twist']=mdp.Sim2realVelocityCommandCfg(**cmd)
    cfg.curriculum.pop('standing_envs',None)  # explicit buckets own exact zero exposure
    cfg.events['sim2real_standing_reset']=EventTermCfg(func=mdp.sim2real_reset_balance_pose,mode='reset')
    cfg.metrics['sim2real_camera']=MetricsTermCfg(func=mdp.sim2real_camera_sample,per_substep=True)
    cfg.rewards['zero_motion']=RewardTermCfg(func=mdp.sim2real_idle_cost,weight=-.1)
    cfg.rewards['idle_leg_pose_l1']=RewardTermCfg(func=mdp.sim2real_idle_leg_pose_cost,weight=-.5)
    cfg.rewards['idle_height_l1']=RewardTermCfg(func=mdp.sim2real_idle_height_cost,weight=-7.5)
    cfg.rewards['straight_path']=RewardTermCfg(func=mdp.sim2real_straight_cost,weight=-.1)
    cfg.rewards['velocity_bias']=RewardTermCfg(func=mdp.sim2real_velocity_bias_cost,weight=0.)
    cfg.curriculum['velocity_bias_weight']=CurriculumTermCfg(func=mdp.reward_weight,
        params={'reward_name':'velocity_bias','weight_stages':[
            {'step':i*24,'weight':w}for i,w in ((0,0.),(600,-1.),(1000,-2.),(1500,-3.))]})
    legs=tuple(side+'_'+joint for side in ('left','right')for joint in ('hip_yaw','hip_roll','hip_pitch','knee','ankle'))
    cfg.rewards['leg_limit_proximity']=RewardTermCfg(func=mdp.joint_pos_limit_proximity,weight=-2.,
        params={'asset_cfg':SceneEntityCfg('robot',joint_names=legs,preserve_order=True),
                'margin':.10,'physical_output':True})
    # The existing L1 cost is only0.2 per yaw joint at its stop. Frozen
    #2600 HOME parked there despite good survival. Price both physical yaw
    # outputs before the stop; do not clip targets or widen CAD constraints.
    cfg.rewards['hip_yaw_limit_proximity']=RewardTermCfg(func=mdp.joint_pos_limit_proximity,weight=-20.,
        params={'asset_cfg':SceneEntityCfg('robot',joint_names=('left_hip_yaw','right_hip_yaw'),preserve_order=True),
                'margin':.10,'physical_output':True})
    #75% frozen evaluation found healthy right-yaw parking for1.1s after
    # backward motion had stopped. Price that HOME return specifically,
    # without increasing the active turning/gait tax or clipping targets.
    cfg.rewards['idle_hip_yaw_limit_proximity']=RewardTermCfg(func=mdp.sim2real_idle_limit_proximity,weight=-40.,
        params={'asset_cfg':SceneEntityCfg('robot',joint_names=('left_hip_yaw','right_hip_yaw'),preserve_order=True),
                'margin':.10})
    cfg.rewards['hip_roll_limit_proximity']=RewardTermCfg(func=mdp.joint_pos_limit_proximity,weight=-20.,
        params={'asset_cfg':SceneEntityCfg('robot',joint_names=('left_hip_roll','right_hip_roll'),preserve_order=True),
                'margin':.10,'physical_output':True})
    cfg.rewards['track_linear_velocity'].weight=3.
    cfg.curriculum['action_rate_weight']=CurriculumTermCfg(func=mdp.reward_weight,
        params={'reward_name':'action_rate_l2','weight_stages':[
            {'step':i*24,'weight':w}for i,w in ((0,-.05),(500,-.1),(750,-.2),(1000,-.3),(1250,-.4),(1500,-.5))]})
    cfg.rewards['head_pose_bias'].params.update(squared=True,rebase_command=True,
        standing_neck_multiplier=13.115759498392228,deadband_rad=mdp.SIM2REAL_HEAD_POSITION_BAND)
    cfg.curriculum['head_pose_bias_weight']=CurriculumTermCfg(func=mdp.reward_weight,
        params={'reward_name':'head_pose_bias','weight_stages':[
            {'step':i*24,'weight':17.28564093268041*f}for i,f in ((0,0.),(600,1/3),(1000,2/3),(1500,1.))]})
    for name,func in [('track_linear_velocity',mdp.sim2real_gait_linear_velocity),
                      ('track_angular_velocity',mdp.sim2real_gait_yaw_velocity)]:
        cfg.rewards[name].func=func
        cfg.rewards[name].params={}
    cfg.rewards['track_angular_velocity'].params={'std':.3}
    cfg.rewards['healthy_height']=RewardTermCfg(func=mdp.sim2real_walk_height_quality,weight=1.,
        params={'idle_height':.112,'moving_height':.105,'low_height':.08})
    cfg.rewards['head_ground']=RewardTermCfg(func=mdp.sim2real_head_ground_cost,weight=-2.)
    cfg.rewards['camera_motion']=RewardTermCfg(func=mdp.sim2real_camera_cost,weight=0.)
    cfg.curriculum['camera_motion_weight']=CurriculumTermCfg(func=mdp.reward_weight,
        params={'reward_name':'camera_motion','weight_stages':[
            {'step':i*24,'weight':-.1*f}for i,f in ((0,0.),(600,1/3),(1000,2/3),(1500,1.))]})
    for section in (cfg.rewards,cfg.curriculum):
        for term in section.values():_replace_standing_height(term.params)
    guard_curricula(cfg)
    return cfg


from mjlab_microduck.tasks import MicroduckOnPolicyRunner

class Sim2realRunner(MicroduckOnPolicyRunner):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        self.completed_updates=0
        self.allocation_kind='qualification'
        self.managed_curriculum=False
        native=self.alg.update
        def counted_update():
            result=native();self.completed_updates+=1
            return result
        self.alg.update=counted_update

    def learn(self,num_learning_iterations,init_at_random_ep_len=False):
        if self.allocation_kind=='qualification' and self.completed_updates+num_learning_iterations>16:
            raise ValueError('Qualification is limited to 16 total updates')
        if self.allocation_kind=='formal' and not self.managed_curriculum:
            raise ValueError('Use scripts/train_v2_sim2real.py for bounded, assessed training')
        self.current_learning_iteration=self.completed_updates
        try:
            result=super().learn(num_learning_iterations,init_at_random_ep_len)
            self.current_learning_iteration=self.completed_updates
            return result
        finally:
            writer=self.logger.writer
            if writer is not None and self.logger.logger_type=='tensorboard':
                writer.close();self.logger.writer=None

    def save(self,path,infos=None):
        from .sim2real_learning import checkpoint_record,capture_rng
        info=checkpoint_record(self.env.unwrapped)
        info.update(completed_updates=self.completed_updates,allocation_kind=self.allocation_kind,
                    learning_rate=self.alg.learning_rate,rng=capture_rng(self.env.unwrapped))
        return super().save(path,{**(infos or {}),'sim2real_baseline_20261021':info})

    def load(self,path,*args,**kwargs):
        saved=torch.load(path,map_location='cpu',weights_only=False)
        record=saved.get('infos',{}).get('sim2real_baseline_20261021')
        env=self.env.unwrapped
        from .sim2real_learning import validate_record,restore_learning_state,restore_rng,normal_buffer_lifetimes
        validate_record(record,env._sim2real_kind)
        if env._sim2real_training_num_envs!=record['batch_contract']['num_envs']:
            raise ValueError('Restore checkpoint batch recipe before constructing the environment')
        if self.allocation_kind=='formal' and record['allocation_kind']!='formal':
            raise ValueError('Qualification policies cannot seed formal training')
        # RSL replaces normalizer std during inference-mode collection. Loading
        # into the same runner must use mutable ordinary buffers again.
        normal_buffer_lifetimes(self.alg.actor)
        normal_buffer_lifetimes(self.alg.critic)
        result=super().load(path,*args,**kwargs)
        self.completed_updates=record['completed_updates']
        self.current_learning_iteration=self.completed_updates
        self.alg.learning_rate=record['learning_rate']
        restore_learning_state(env,record)
        restore_rng(record['rng'],env)
        # Restart episodes explicitly: physics was not serialized. Clear episode
        # caches before reset so old measurements cannot pollute recent windows.
        mdp.sim2real_state(env)['clock']=-1
        env.reset()
        return result


def register():
    from mjlab.tasks.registry import load_rl_cfg,register_mjlab_task
    from mjlab_microduck.tasks import MicroduckOnPolicyRunner
    for task,factory,source in [(RISE_TASK,rise_cfg,paired_randomization.TASK),(WALK_TASK,walk_cfg,v2.TASK_ID)]:
        agent=deepcopy(load_rl_cfg(source));agent.seed=20261021
        agent.experiment_name='v2_sim2real_baseline_'+('rise'if task==RISE_TASK else'walk')
        agent.run_name='fresh_6246g_cad';agent.resume=False;agent.upload_model=False
        agent.num_steps_per_env=24;agent.algorithm.num_learning_epochs=5;agent.algorithm.num_mini_batches=4
        agent.algorithm.class_name='mjlab_microduck.custom_v2.ppo:TerminalCriticPPO'
        register_mjlab_task(task_id=task,env_cfg=factory(),play_env_cfg=factory(True),rl_cfg=agent,runner_cls=Sim2realRunner)
