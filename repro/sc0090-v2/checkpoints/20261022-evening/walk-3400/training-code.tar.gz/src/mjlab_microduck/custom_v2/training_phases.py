"""Explicit, checkpointed difficulty stages; final hardware envelope is retained.

Each physics stage starts in a new environment. Switching stage requires a
matching qualification and an explicit checkpoint transition, never elapsed time.
"""
from dataclasses import replace
from functools import partial
import hashlib,math
import mujoco

PHASES=('foundation','random025','random050','random100','robust')
WALK_TRANSPORT_BRIDGE='random050_transport025'
WALK_FULL_BRIDGE='random100_transport050'
WALK_THREE_QUARTER_BRIDGE='random075_transport050'
WALK_PHASES=('foundation','random025',WALK_TRANSPORT_BRIDGE,'random050',WALK_THREE_QUARTER_BRIDGE,WALK_FULL_BRIDGE,'random100','robust')
STRENGTH=dict(foundation=0.,random025=.25,random050_transport025=.5,random050=.5,random075_transport050=.75,random100_transport050=1.,random100=1.,robust=1.,legacy_full=1.)
WALK_IDLE_REPAIR_SOURCE='c36a5ce40f1573994ac60a13dcb1fa5d80ab513ead10d18066118ece67ca2335'
WALK_VELOCITY_REPAIR_SOURCE='b6772cbdcf78c0f33932349923011271cc217a05e8ed29dcfd72e19e464e0c27'
WALK_CLEARANCE_SOURCE='bd49afb51158c67ad87b5c42d3d63415b7f8b9c3a5e2e83b1dbfeeb2fe7f34f0'
WALK_CLEARANCE_OLD_GEOMETRY='23cd33d1d1d37794cbb1c76f989e25830ec9911d32dcba030669ebdc2b31f42c'


def phase_sequence(kind):
    return WALK_PHASES if kind=='walk'else PHASES


def command_delay_lags(phase):
    if phase==WALK_TRANSPORT_BRIDGE:return (0,1)
    if phase in (WALK_THREE_QUARTER_BRIDGE,WALK_FULL_BRIDGE):return (1,2)
    s=STRENGTH[phase]
    return round(2*s),round(5*s)


def phase_model_path(kind,phase):
    from .sim2real import SOURCE_MODELS,MODELS
    if phase==WALK_TRANSPORT_BRIDGE:
        if kind!='walk':raise ValueError('Transport bridge is walking-only')
        phase='random050'
    if phase==WALK_THREE_QUARTER_BRIDGE:
        if kind!='walk':raise ValueError('Transport bridge is walking-only')
        return MODELS[kind].with_name('robot_sim2real_walk_backlash_075.xml')
    if phase==WALK_FULL_BRIDGE:
        if kind!='walk':raise ValueError('Transport bridge is walking-only')
        phase='random100'
    if phase=='foundation':return SOURCE_MODELS[kind]
    if phase in ('random025','random050'):
        return MODELS[kind].with_name(f'robot_sim2real_{kind}_backlash_{phase[-3:]}.xml')
    if phase in ('random100','robust','legacy_full'):return MODELS[kind]
    raise ValueError('Unknown training phase')


def phase_spec(kind,phase):
    return mujoco.MjSpec.from_file(str(phase_model_path(kind,phase)))


def phase_contract(kind,phase):
    from .sim2real import RANDOMIZATION_CONTRACT
    s=STRENGTH[phase]
    return dict(phase=phase,strength=s,kind=kind,
        geometry_sha256=hashlib.sha256(phase_model_path(kind,phase).read_bytes()).hexdigest(),
        mass_kg=.6246,backlash_total_width_deg=2*s,
        encoder_bias_deg=2*s,paired_error_strength=s,imu_misalignment_max_deg=6*s,
        command_delay_physics_steps=list(command_delay_lags(phase)),
        supply_voltage_v=[11.1+s*(10.2-11.1),11.1+s*(12.4-11.1)],
        supply_resistance_ohm=[.05*s,.15*s],
        motor_friction_and_armature_scale=[1-.1*s,1+.1*s],
        disturbances=phase in ('robust','legacy_full'),
        balance_spawn_trials=phase in ('robust','legacy_full'),
        final_target=RANDOMIZATION_CONTRACT)


def configure_phase(cfg,phase):
    """Apply once, before batch scaling/simulator construction, to a fresh cfg."""
    from mjlab.managers import CurriculumTermCfg
    from mjlab_microduck.tasks import mdp
    kind=cfg.events['sim2real_initialize'].params['kind']
    if phase not in phase_sequence(kind):raise ValueError('An explicit supported phase is required')
    if hasattr(cfg,'_sim2real_phase'):raise ValueError('Apply the physics phase only once')
    kind=cfg.events['sim2real_initialize'].params['kind'];s=STRENGTH[phase]
    cfg._sim2real_phase=phase
    cfg.events['sim2real_initialize'].params['training_phase']=phase
    robot=cfg.scene.entities['robot'];robot.spec_fn=partial(phase_spec,kind,phase)
    actuator=robot.articulation.actuators[0]
    robot.articulation.actuators=(replace(actuator,
        encoder_through_backlash=s>0,command_transport_delay=True,
        delay_min_lag=command_delay_lags(phase)[0],delay_max_lag=command_delay_lags(phase)[1],
        randomized_supply=True,vin=11.1,
        vin_range=(11.1+s*(10.2-11.1),11.1+s*(12.4-11.1)),
        supply_resistance_range=(.05*s,.15*s)),)
    events=cfg.events
    events['encoder_bias'].params['bias_range']=(-math.radians(2)*s,math.radians(2)*s)
    events['randomize_joint_friction'].params['scale_range']=(1-.1*s,1+.1*s)
    events['randomize_armature'].params['ranges']=(1-.1*s,1+.1*s)
    for name in ('randomize_com','randomize_head_com'):
        events[name].params['ranges']=tuple(v*s for v in events[name].params['ranges'])
    events['randomize_mass_inertia'].params['alpha_range']=tuple(v*s for v in events['randomize_mass_inertia'].params['alpha_range'])
    events['base_com'].params['ranges']={k:tuple(v*s for v in pair)for k,pair in events['base_com'].params['ranges'].items()}
    m=robot.spec_fn().compile();nominal=float(m.geom('left_foot_collision').friction[0])
    events['foot_friction'].params['ranges']=tuple(nominal+s*(v-nominal)for v in events['foot_friction'].params['ranges'])
    obs=cfg.observations['actor'];obs.enable_corruption=s>0
    for name in ('joint_pos','joint_vel'):obs.terms[name].params['strength']=s
    for name in ('base_ang_vel','projected_gravity'):
        term=obs.terms[name];term.params['max_angle_deg']=6*s
        if term.noise is not None:
            term.noise.n_min*=s;term.noise.n_max*=s
        term.delay_min_lag=0;term.delay_max_lag=0 if s==0 else term.delay_max_lag
    # Initial-state/command randomness is task exposure, not hardware DR.
    # Foundation keeps all recovery poses and walk/stop/turn commands.
    if kind=='rise':events['set_ground_state'].params['balance_trials']=phase=='robust'
    else:events['sim2real_standing_reset'].params['locomotion_fraction']=.30 if phase=='robust'else 0.
    for name in ('sim2real_topple_push','sim2real_push_magnitude'):
        cfg.curriculum.pop(name,None)
    if phase!='robust':
        for name in ('push_robot','topple_push','sim2real_balanced_push'):events.pop(name,None)
        for name in ('balance_quality','outward_tilt','balance_fall'):cfg.rewards[name].weight=0.
    else:
        cfg.curriculum['sim2real_disturbance']=CurriculumTermCfg(func=mdp.sim2real_disturbance_curriculum)
        for name,v in (('push_robot',.3 if kind=='walk'else .08),('topple_push',.3)):
            events[name].params['velocity_range']={'x':(-v,v),'y':(-v,v)}
    return phase_contract(kind,phase)


def configure_evaluation_profile(cfg,record,profile='training'):
    phase=record.get('training_phase','legacy_full')
    effective=phase if profile=='training'else 'foundation'if profile=='nominal'else 'random100'
    if profile not in ('training','nominal','full'):raise ValueError('Unknown evaluation profile')
    if effective!='legacy_full':configure_phase(cfg,effective)
    cfg.events['sim2real_initialize'].params['evaluation_profile']=profile
    return effective


def phase_promotable(record):
    """Primary motion mastery, independent of four-degree/head precision tests."""
    if record['kind']=='rise':
        h=record.get('eval_history',{})
        return bool(h.get('motion_mastered')and h.get('sufficient_coverage')and
                    h.get('training_phase')==record.get('training_phase'))
    from .assessment import WALK_PHASE_CRITERION
    h=record.get('eval_history',{})
    return bool(record['curriculum']['stage']==2 and h.get('phase_ready')and
        h.get('phase_criterion')==WALK_PHASE_CRITERION and not h.get('sustained_yaw_parking')and not h.get('sustained_idle_roll_parking')and
        h.get('sufficient_coverage')and h.get('training_phase')==record.get('training_phase')and
        h.get('common_step_counter')==record.get('common_step_counter')and
        h.get('recipe_sha256')==record.get('recipe_sha256'))


def transition_phase_record(record,source_sha,proof):
    """Explicit compatible-policy transition; new physical episodes/stat cohort."""
    from copy import deepcopy
    from .sim2real import RANDOMIZATION_CONTRACT,RISE_TASK,WALK_TASK
    from .sim2real_learning import recipe_sha256,validate_record,TENSORS
    legacy={'rise':'202fb2ed5f1f5cdba5f8dbb3fb80f588d08bb483fba1cbd3ed234b32e02b1a15',
            'walk':'054ffee57128797ee33236f4739973ce55559dca5cc669be69d2eaae17539694'}
    kind=record.get('kind');source_phase=record.get('training_phase','legacy_full')
    if kind=='walk'and record.get('recipe_sha256')!=recipe_sha256():
        raise ValueError('Historical walking continuation retired after limit-parking audit; use verified healthy rollback or fresh initialization')
    target=proof.get('training_phase')
    idle_repair=(kind=='walk'and source_phase==target=='foundation'and record.get('recipe_sha256')==WALK_IDLE_REPAIR_SOURCE)
    velocity_repair=(kind=='walk'and source_phase==target=='foundation'and record.get('recipe_sha256')==WALK_VELOCITY_REPAIR_SOURCE)
    clearance_repair=(kind=='walk'and source_phase==target=='foundation'and
        record.get('recipe_sha256')==WALK_CLEARANCE_SOURCE and record.get('completed_updates')==6400)
    same_phase_repair=idle_repair or velocity_repair or clearance_repair
    if kind not in legacy or record.get('schema')!=3 or record.get('allocation_kind')!='formal':
        raise ValueError('Only identified formal policies support phase continuation')
    if source_phase=='legacy_full':
        if (record.get('recipe_sha256')!=legacy[kind]or target!='foundation'or
            record.get('randomization_contract')!=RANDOMIZATION_CONTRACT):
            raise ValueError('Only the retained current run may enter foundation repair')
    elif not same_phase_repair:
        validate_record(record,kind)
        phases=phase_sequence(kind);index=phases.index(source_phase)
        if index==len(phases)-1 or target!=phases[index+1]or not phase_promotable(record):
            raise ValueError('Next physics phase requires primary motion mastery in the active profile')
    expected_geometry=hashlib.sha256(phase_model_path(kind,source_phase).read_bytes()).hexdigest()
    if clearance_repair:expected_geometry=WALK_CLEARANCE_OLD_GEOMETRY
    task=RISE_TASK if kind=='rise'else WALK_TASK
    if (record.get('geometry_sha256')!=expected_geometry or target not in phase_sequence(kind) or
        proof.get('status')!='PASS'or proof.get('task')!=task or
        proof.get('num_envs')!=record['batch_contract']['num_envs']or
        proof.get('recipe_sha256')!=recipe_sha256()or proof.get('phase_contract')!=phase_contract(kind,target)):
        raise ValueError('Phase transition source geometry or target qualification mismatch')
    if same_phase_repair:
        source_contract=phase_contract(kind,source_phase)
        if clearance_repair:source_contract['geometry_sha256']=WALK_CLEARANCE_OLD_GEOMETRY
        if record.get('randomization_contract')!=source_contract:
            raise ValueError('Reward repair requires the same physical phase')
        new=deepcopy(record);new['recipe_sha256']=recipe_sha256()
        reset=[]
        if clearance_repair:
            new['randomization_contract']=phase_contract(kind,target)
            new['geometry_sha256']=new['randomization_contract']['geometry_sha256']
            reset=list(TENSORS)
            for key in reset:new['curriculum'][key].zero_()
            new['curriculum'].update(stage=0,balance_stage=0,push_stage=0,window_cursor=0,
                last_review=record['common_step_counter'],last_promotion=record['common_step_counter'])
            new['eval_history']=dict(training_phase=target)
        new.setdefault('migration_history',[]).append(dict(
            repair=('CAD_trunk_concavity_collision_repair_from_retained_6400'if clearance_repair else
                    'dense_velocity_band_l1_and_equivalent_cpu_assessment_batching'if velocity_repair else
                    'zero_command_leg_and_height_l1_for_crouched_idle_plateau'),
            source_checkpoint_sha256=source_sha,source_recipe_sha256=record['recipe_sha256'],
            target_recipe_sha256=recipe_sha256(),source_training_phase=source_phase,
            target_training_phase=target,completed_updates=record['completed_updates'],
            source_geometry_sha256=expected_geometry,target_geometry_sha256=new['geometry_sha256'],
            reset_phase_statistics=reset,policy_optimizer_normalizer_rng_and_update_counters='preserved',
            physics='CAD collision changed; new physical cohort'if clearance_repair else 'same phase; new episodes as ordinary resume'))
        validate_record(new,kind)
        return new
    new=deepcopy(record);new['training_phase']=target;new['recipe_sha256']=recipe_sha256()
    new['randomization_contract']=phase_contract(kind,target)
    new['geometry_sha256']=new['randomization_contract']['geometry_sha256']
    for key in TENSORS:new['curriculum'][key].zero_()
    new['curriculum'].update(stage=0,balance_stage=0,push_stage=0,window_cursor=0,
        last_review=record['common_step_counter'],last_promotion=record['common_step_counter'])
    if kind=='walk':new['curriculum']['stage']=2  # already mastered full command exposure in the preceding physics phase
    reference=record['common_step_counter']*record['batch_contract']['reference_learning_step_factor']
    new['eval_history']=dict(last_promotion_reference_step=reference,training_phase=target)
    new['precision_start_reference_step']=None
    if new['recovery']is not None:
        r=new['recovery'];r.update(discovery=True,polish=False,last_assessment_step=record['common_step_counter'],
            trials=[0]*7,wins=[0]*7,rates=[0.]*7,total_trials=[0]*7)
    new.setdefault('migration_history',[]).append(dict(
        repair='explicit_staged_training_after_user_review',source_checkpoint_sha256=source_sha,
        source_recipe_sha256=record['recipe_sha256'],target_recipe_sha256=recipe_sha256(),
        source_training_phase=source_phase,target_training_phase=target,
        source_geometry_sha256=expected_geometry,target_geometry_sha256=new['geometry_sha256'],
        completed_updates=record['completed_updates'],reset_phase_statistics=list(TENSORS),
        policy_optimizer_normalizer_rng_and_update_counters='preserved',
        source_phase_evaluation_history=deepcopy(record.get('eval_history',{})),
        head_precision_budget='starts only after final robustness mastery',
        physics='new episodes; exact model/phase contract recorded'))
    validate_record(new,kind)
    return new
