"""Frozen-policy behavior acceptance with shared training measurements."""
from pathlib import Path
from dataclasses import asdict
import argparse,json,hashlib,math
import torch
from mjlab.tasks.registry import load_env_cfg,load_rl_cfg,load_runner_cls
from mjlab.envs import ManagerBasedRlEnv
from mjlab.rl import RslRlVecEnvWrapper
from mjlab.managers import EventTermCfg
from mjlab_microduck.custom_v2.sim2real import RISE_TASK,WALK_TASK
from mjlab_microduck.custom_v2.sim2real_learning import KEY,apply_checkpoint_recipe
from mjlab_microduck.custom_v2.assessment import (cases_for,duration_for,command_multiplier,
    summarize,CRITERIA,PROTOCOL_VERSION,DT)
from mjlab_microduck.tasks import mdp


def main():
    parser=argparse.ArgumentParser(__doc__)
    parser.add_argument('--skill',choices=['rise','walk'],required=True)
    parser.add_argument('--protocol',choices=['recovery','tilt','slow_push','fast_push','four_way_push','walking','straight','head'],required=True)
    parser.add_argument('--checkpoint',type=Path,required=True);parser.add_argument('--output',type=Path,required=True)
    parser.add_argument('--device',default='cuda:0');parser.add_argument('--seed',type=int,default=2026102102)
    parser.add_argument('--samples',type=int,default=8)
    parser.add_argument('--evaluation-profile',choices=['training','nominal','full'],default='training')
    a=parser.parse_args()
    if a.samples<1 or(a.protocol=='recovery'and a.skill!='rise'):raise ValueError('Invalid protocol/sample count')
    if a.protocol in ('walking','straight')and a.skill!='walk':raise ValueError('Walking protocol needs walking task')
    a.output.mkdir(parents=True,exist_ok=False);torch.set_num_threads(2);torch.cuda.set_device(a.device)
    task=RISE_TASK if a.skill=='rise'else WALK_TASK
    cases=cases_for(a.protocol);duration=duration_for(a.protocol);steps=round(duration/DT)
    cfg=load_env_cfg(task);agent=load_rl_cfg(task)
    record=torch.load(a.checkpoint,map_location='cpu',weights_only=False)['infos'][KEY]
    protocol_version=PROTOCOL_VERSION
    if a.skill=='rise' and record.get('head_repair'):
        CRITERIA['head_absolute_band_rad']=math.radians(2)
        protocol_version=5
    apply_checkpoint_recipe(cfg,agent,record,evaluation_num_envs=len(cases)*a.samples,evaluation_profile=a.evaluation_profile)
    cfg.seed=a.seed;cfg.auto_reset=False;cfg.terminations={};cfg.episode_length_s=duration+1.
    cfg.events={k:v for k,v in cfg.events.items()if v.mode!='interval'and k!='sim2real_balanced_push'}
    cfg.curriculum.pop('sim2real_competence',None)
    cfg.curriculum.pop('sim2real_push_magnitude',None)
    cfg.curriculum.pop('sim2real_topple_push',None)
    cfg.curriculum.pop('sim2real_disturbance',None)
    if a.protocol=='recovery':cfg.events['set_ground_state'].params['evaluation_buckets']=True
    else:
        key='set_ground_state'if a.skill=='rise'else 'sim2real_standing_reset'
        cfg.events[key]=EventTermCfg(func=mdp.sim2real_evaluation_reset,mode='reset')
    if 'push'in a.protocol:
        cfg.events['sim2real_eval_force']=EventTermCfg(func=mdp.sim2real_force_step,mode='step',params={'evaluation':True})
    initialize=cfg.events['sim2real_initialize'].func
    def init(env,env_ids=None,**kwargs):
        initialize(env,env_ids,**kwargs)
        env._sim2real_eval_pose_index=torch.tensor([env._sim2real_pose_rows_2d[c.get('pitch_deg',0),c.get('roll_deg',0)]for c in cases],device=env.device).repeat_interleave(a.samples)
        env._sim2real_eval_outward_rate=torch.tensor([c.get('outward_rate_rad_s',0.)for c in cases],device=env.device).repeat_interleave(a.samples)
        if 'push'in a.protocol:
            env._sim2real_eval_push={key:torch.tensor([c[key]for c in cases],device=env.device,
                dtype=torch.long if key in ('direction','mode')else torch.float32).repeat_interleave(a.samples)
                for key in ('direction','mode','peak','duration')}
    cfg.events['sim2real_initialize'].func=init
    (a.output/'resolved-config.json').write_text(json.dumps(dict(env=asdict(cfg),criteria=CRITERIA,protocol_version=protocol_version),indent=2,default=str)+'\n')
    env=ManagerBasedRlEnv(cfg,device=a.device)
    try:
        agent.upload_model=False;wrapped=RslRlVecEnvWrapper(env,clip_actions=agent.clip_actions)
        runner=load_runner_cls(task)(wrapped,asdict(agent),None,a.device)
        runner.load(str(a.checkpoint),map_location=a.device)
        actor=runner.alg.get_policy().eval();frozen={k:v.clone()for k,v in actor.state_dict().items()}
        targets=torch.tensor([c.get('twist',[0.]*3)for c in cases],device=a.device).repeat_interleave(a.samples,0)
        heads=torch.tensor([c.get('head',[0.]*4)for c in cases],device=a.device).repeat_interleave(a.samples,0)
        desired=torch.zeros_like(targets);head=torch.zeros_like(heads)
        native=env.command_manager.compute
        def commands(dt):
            native(dt);env.command_manager.get_command('twist').copy_(desired)
            env.command_manager.get_command('head_pose').copy_(head)
            env.command_manager.get_command('body_pose').zero_()
        env.command_manager.compute=commands
        obs,_=env.reset(seed=a.seed)
        storage={};index=[0];reward=env.reward_manager.compute
        head_ids,_=env.scene['robot'].find_joints(('neck_pitch','head_pitch','head_yaw','head_roll'),preserve_order=True)
        root_global=env.scene['robot'].indexing.body_ids[mdp.sim2real_state(env)['root_ids']]
        def record_metrics(dt):
            value=reward(dt);s=mdp.sim2real_measure(env)
            fields=('pitch','pitch_rate','roll','roll_rate','height','tilt','yaw','lin','ang','feet','head_contact',
                'self_contact','healthy','stable','quiet','finite','head_gate','previous_command','velocity_mean',
                'command_age','head_command_age','tracking_hold','leg_speed','balance_mean','settled')
            values={k:s[k]for k in fields}
            actual_force=env.sim.data.xfrc_applied[:,root_global,:3]
            torch._assert_async(((actual_force-s['force']).abs()<1e-7).all(),'Requested force differs from physics wrench')
            values.update(qpos=env.sim.data.qpos,qvel=env.sim.data.qvel,actor_observation=obs['actor'],
                raw_action=env.action_manager.action,continuous_target=env.action_manager.get_term('joint_pos')._processed_actions,
                policy_joint_position=mdp.sim2real_joint_outputs(env)[0][:,mdp._servo_joint_ids(env,env.scene['robot'])],
                applied_force=actual_force,head_command=env.command_manager.get_command('head_pose'),
                head_position=mdp.sim2real_joint_outputs(env)[0][:,head_ids])
            if 'camera_energy'in s:values['camera_energy']=s['camera_energy']
            if not storage:storage.update({k:torch.empty((steps,*v.shape),dtype=v.dtype,device=v.device)for k,v in values.items()})
            for k,v in values.items():storage[k][index[0]].copy_(v)
            return value
        env.reward_manager.compute=record_metrics
        with torch.inference_mode():
            for step in range(steps):
                index[0]=step;factor=command_multiplier(step*DT,a.protocol)
                torch._assert_async((obs['actor'][:,48:51]==targets*factor).all(),'Twist command boundary mismatch')
                torch._assert_async((obs['actor'][:,51:55]==heads*factor).all(),'Head command boundary mismatch')
                next_factor=command_multiplier((step+1)*DT,a.protocol)
                desired.copy_(targets*next_factor);head.copy_(heads*next_factor)
                obs,*_=wrapped.step(actor(obs))
        for k,v in actor.state_dict().items():assert torch.equal(v,frozen[k]),k
        data={k:v.cpu()for k,v in storage.items()};torch.save(data,a.output/'traces.pt')
        home_output=None
        home_case=next((i for i,c in enumerate(cases)if c['name']in ('neutral','idle')),None)
        if home_case is not None:
            idx=slice(home_case*a.samples,(home_case+1)*a.samples)
            raw=data['raw_action'][:,idx];target=data['continuous_target'][:,idx]
            position=data['policy_joint_position'][:,idx]
            band=0.5235987755982988  # 30deg startup/idle target guard; head precision remains2deg.
            first=raw[0].abs().amax(0);tail=raw[-50:].abs().amax((0,1))
            clipped=(raw-target).abs()>1e-5
            home_output=dict(case=cases[home_case]['name'],samples=a.samples,
                target_band_rad=band,first_raw_action_rad=raw[0,0].tolist(),
                first_max_absolute_per_joint_rad=first.tolist(),tail_max_absolute_per_joint_rad=tail.tolist(),
                tail_mean_raw_action_rad=raw[-50:].mean((0,1)).tolist(),
                tail_mean_physical_joint_position_rad=position[-50:].mean((0,1)).tolist(),
                clipped_fraction_per_joint=clipped.float().mean((0,1)).tolist(),
                never_fell=bool((~data['fallen'][:,idx]).all())if 'fallen'in data else bool((data['tilt'][:,idx]<1.2217304763960306).all()),
                small_and_unsaturated=bool((first<=band).all()and(tail<=band).all()and not clipped.any()),
                role='additional HOME enable/idle acceptance; not a restriction on floor recovery or moving commands')
        rows=summarize(data,cases,a.samples,a.protocol)
        report=dict(status='EVALUATED',protocol=a.protocol,protocol_version=protocol_version,
            home_policy_output=home_output,
            training_phase=record.get('training_phase','legacy_full'),evaluation_profile=a.evaluation_profile,
            effective_phase=getattr(env,'_sim2real_training_phase','legacy_full'),
            task=task,seed=a.seed,duration_s=duration,criteria=CRITERIA,records=rows,
            checkpoint_sha256=hashlib.sha256(a.checkpoint.read_bytes()).hexdigest(),recipe_sha256=record['recipe_sha256'],
            batch_contract=record['batch_contract'],restored_clock=record['common_step_counter'],
            diagnostic_controls=steps*env.num_envs,learning_updates=0,
            training_evaluation_body_criteria_equal=True,
            force_verified_against_physics=True,
            measurement_boundary='after_reward_before_reset/command; geometry lags5ms',
            signal_definitions=dict(velocity='training 0.5s EMA',standing_head='0.1s physical mean',moving_head='1s physical mean',
                settling='continuous0.5s in target band; command-specific transition origin'),
            scope='Frozen actor/normalizer; original paired DR; fixed commands and declared physical forces; no autoreset. EVALUATED is not a skill-pass claim.')
        (a.output/'report.json').write_text(json.dumps(report,indent=2,allow_nan=False)+'\n')
    finally:env.close()


if __name__=='__main__':main()
