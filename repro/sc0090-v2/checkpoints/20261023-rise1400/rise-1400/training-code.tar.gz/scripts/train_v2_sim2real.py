"""Explicitly bounded baseline allocation with isolated recovery assessments.

Default mode is qualification (<=16 updates total, discarded weights). Formal
mode is for a separately authorized run, requires a matching finite preflight,
and always requires an explicit update budget. Never called automatically.
"""
import argparse,json,os,signal,subprocess,sys,threading,time,traceback
from dataclasses import asdict
from pathlib import Path
START=time.monotonic()


def write_json(path,value):
    tmp=path.with_suffix('.tmp');tmp.write_text(json.dumps(value,indent=2,default=str,allow_nan=False)+'\n');tmp.replace(path)


def main():
    p=argparse.ArgumentParser(__doc__)
    p.add_argument('--skill',choices=['rise','walk'],required=True)
    p.add_argument('--device',required=True);p.add_argument('--output',type=Path,required=True)
    p.add_argument('--mode',choices=['qualification','formal'],default='qualification')
    p.add_argument('--num-envs',type=int,choices=[64,8192,16384,20480],default=64)
    p.add_argument('--updates',type=int,required=True)
    p.add_argument('--resume',type=Path);p.add_argument('--preflight',type=Path)
    p.add_argument('--training-phase',choices=['foundation','random025','random050','random100','robust'])
    p.add_argument('--eval-samples',type=int,default=128)
    p.add_argument('--eval-reference-updates',type=int,default=100)
    p.add_argument('--verify-behavior',action='store_true',help='Exercise complete behavior reports in a bounded qualification')
    a=p.parse_args()
    if a.updates<1 or a.eval_reference_updates<1:raise ValueError('Positive explicit budgets required')
    if a.mode=='qualification' and a.updates>16:raise ValueError('Qualification budget is at most 16')
    if a.eval_samples<2 or a.eval_samples%2:raise ValueError('Evaluation samples must be even')
    if a.mode=='formal' and (a.eval_samples!=128 or a.eval_reference_updates!=100 or a.num_envs==64):
        raise ValueError('Formal assessment is fixed: 2 seeds x 128/group every 100 reference updates')
    import torch
    from mjlab.envs import ManagerBasedRlEnv
    from mjlab.rl import RslRlVecEnvWrapper
    from mjlab.tasks.registry import load_env_cfg,load_rl_cfg,load_runner_cls
    from mjlab_microduck.custom_v2.sim2real import RISE_TASK,WALK_TASK,configure_batch_size
    from mjlab_microduck.custom_v2.sim2real_learning import (
        KEY,apply_checkpoint_recipe,assess_checkpoint,precision_budget_remaining,recipe_sha256,curriculum_snapshot)
    torch.set_num_threads(2);torch.cuda.set_device(a.device)
    task=RISE_TASK if a.skill=='rise'else WALK_TASK
    from mjlab_microduck.custom_v2.training_phases import configure_phase,phase_promotable
    from mjlab_microduck.custom_v2.sim2real_learning import checkpoint_record
    record=torch.load(a.resume,map_location='cpu',weights_only=False)['infos'][KEY]if a.resume else None
    phase=record.get('training_phase','legacy_full')if record else(a.training_phase or 'foundation')
    if a.training_phase is not None and a.training_phase!=phase:raise ValueError('Use an explicit stage transition before changing phase')
    if a.mode=='formal':
        if a.preflight is None:raise ValueError('Matching bounded preflight report required')
        proof=json.loads(a.preflight.read_text())
        if (proof.get('status')!='PASS' or proof.get('task')!=task or
            proof.get('num_envs')!=a.num_envs or proof.get('recipe_sha256')!=recipe_sha256()or proof.get('training_phase')!=phase):
            raise ValueError('Preflight task/batch/source mismatch')
        expected_course=((record.get('head_repair')or{}).get('id')if record else None)
        if proof.get('head_course')!=expected_course:
            raise ValueError('Preflight head course mismatch')
        if proof.get('head_exploration')!=((record.get('head_exploration')or{}).get('id')if record else None):
            raise ValueError('Preflight head exploration mismatch')
        replay=(((record or {}).get('head_exploration')or{}).get('standing_replay')or{}).get('id')
        if proof.get('head_replay')!=replay:
            raise ValueError('Preflight standing head replay mismatch')
    cfg=load_env_cfg(task);agent=load_rl_cfg(task)
    cfg.seed=20261021;agent.seed=cfg.seed;agent.logger='tensorboard';agent.upload_model=False
    if a.resume:
        if record['batch_contract']['num_envs']!=a.num_envs:raise ValueError('Resume batch mismatch')
        if record['allocation_kind']!=a.mode:raise ValueError('Do not mix qualification and formal policies')
        contract=apply_checkpoint_recipe(cfg,agent,record)
    else:
        configure_phase(cfg,phase)
        contract=configure_batch_size(cfg,agent,a.num_envs)
    a.output.mkdir(parents=True,exist_ok=False)
    write_json(a.output/'allocation.json',dict(arguments=vars(a),task=task,batch_contract=contract,
        recipe_sha256=recipe_sha256(),training_phase=phase,env=asdict(cfg),agent=asdict(agent),
        purpose='finite verification; discard weights'if a.mode=='qualification'else 'authorized bounded fresh baseline experiment'))
    stopping=[False]
    for sig in (signal.SIGINT,signal.SIGTERM):signal.signal(sig,lambda *_:stopping.__setitem__(0,True))
    gpu=[];stop=threading.Event();timings=[]
    def monitor():
        while not stop.is_set():
            try:
                line=subprocess.check_output(['nvidia-smi','-i',a.device.split(':')[-1],
                    '--query-gpu=utilization.gpu,memory.used','--format=csv,noheader,nounits'],text=True,timeout=5)
                util,mem=map(float,line.strip().split(','));gpu.append(dict(elapsed_s=time.monotonic()-START,utilization_percent=util,memory_MiB=mem))
            except (subprocess.SubprocessError,ValueError):pass
            stop.wait(1)
    thread=threading.Thread(target=monitor,daemon=True);thread.start();env=None
    try:
        env=ManagerBasedRlEnv(cfg,device=a.device)
        runner=load_runner_cls(task)(RslRlVecEnvWrapper(env,clip_actions=agent.clip_actions),asdict(agent),str(a.output),a.device)
        runner.allocation_kind=a.mode;runner.managed_curriculum=True
        if a.resume:runner.load(str(a.resume),map_location=a.device)
        initial=runner.completed_updates;target=initial+a.updates
        if a.mode=='qualification' and target>16:raise ValueError('Resume cannot extend qualification beyond 16 total updates')
        native_log=runner.logger.log
        def log(*args,**kwargs):
            timings.append(dict(completed_updates=runner.completed_updates,collection_s=kwargs['collect_time'],
                learning_s=kwargs['learn_time'],elapsed_s=time.monotonic()-START))
            native_log(*args,**kwargs)
            write_json(a.output/'status.json',dict(status='RUNNING',mode=a.mode,pid=os.getpid(),
                completed_updates=runner.completed_updates,target_updates=target,common_step_counter=env.common_step_counter,
                curriculum=curriculum_snapshot(env)))
        runner.logger.log=log
        interval=max(1,round(a.eval_reference_updates/env._sim2real_reference_factor))
        reason='explicit_budget'
        behavior_interval=max(1,round(400/env._sim2real_reference_factor))
        def behavior(protocol,path,iteration,samples,profile='training'):
            evaluator=Path(__file__).with_name('evaluate_v2_sim2real.py')
            prefix=''if profile=='training'else profile+'-'
            destination=a.output/f'{prefix}{protocol}-assessment-{iteration}'
            if destination.exists():return
            with destination.with_suffix('.log').open('w')as log_file:
                subprocess.run([sys.executable,str(evaluator),'--skill',a.skill,'--protocol',protocol,
                    '--checkpoint',str(path),'--device',a.device,'--samples',str(samples),
                    '--evaluation-profile',profile,
                    '--output',str(destination)],stdout=log_file,stderr=subprocess.STDOUT,check=True)
        while runner.completed_updates<target and not stopping[0]:
            amount=min(target-runner.completed_updates,interval-runner.completed_updates%interval)
            remaining=precision_budget_remaining(env)
            if remaining is not None:
                amount=min(amount,int(remaining/env._sim2real_reference_factor))
                if amount<1:
                    reason='head_repair_budget_review'if getattr(env,'_sim2real_head_repair',None)else'head_precision_budget_review'
                    if getattr(env,'_sim2real_head_exploration',None):reason='head_exploration_budget_review'
                    break
            runner.learn(amount,init_at_random_ep_len=False)
            iteration=runner.completed_updates
            path=a.output/f'assessed-{iteration}.pt';runner.save(str(path))
            if a.skill=='rise':
                report,decision=assess_checkpoint(task,runner,path,a.eval_samples)
                write_json(a.output/f'assessment-{iteration}.json',dict(report=report,decision=decision))
            # Preserve completed PPO and its curriculum decision before a
            # diagnostic subprocess can fail, for both skills. The assessed
            # file remains immutable.
            runner.save(str(a.output/'resume.pt'))
            if a.skill=='rise'and decision['polish']:
                behavior('head',path,iteration,32 if a.mode=='formal'else 2)
            phase_complete=a.mode=='formal'and phase!='robust'and phase_promotable(checkpoint_record(env))
            behavior_due=(iteration//behavior_interval>(iteration-amount)//behavior_interval or iteration==target
                          or phase_complete or precision_budget_remaining(env)==0)
            if (a.mode=='formal'and behavior_due)or a.verify_behavior:
                samples=32 if a.mode=='formal'else 2
                protocols=(('walking','straight','four_way_push')if a.skill=='walk'else('tilt','four_way_push','head'))if phase=='robust'else(('walking','straight')if a.skill=='walk'else('tilt',))
                if a.skill=='rise' and not decision['polish']:
                    protocols=tuple(p for p in protocols if p!='head')
                for protocol in protocols:
                    behavior(protocol,path,iteration,samples)
            if a.mode=='formal'and(iteration==target or phase_complete)and phase!='robust':
                if a.skill=='rise':
                    shadow,_=assess_checkpoint(task,runner,path,a.eval_samples,evaluation_profile='full',apply_decision=False)
                    write_json(a.output/f'full-assessment-{iteration}.json',dict(report=shadow,decision=None))
                else:behavior('walking',path,iteration,32,profile='full')
            # Leave the assessed file immutable; continuation includes the decision.
            runner.save(str(a.output/'resume.pt'))
            if phase_complete:reason='primary_motion_mastery';break
        if stopping[0]:reason='signal'
        runner.save(str(a.output/'resume.pt'))
        stop.set();thread.join(timeout=6)
        write_json(a.output/'gpu-samples.json',gpu)
        write_json(a.output/'timing.json',timings)
        write_json(a.output/'status.json',dict(status='BOUNDED_COMPLETE',mode=a.mode,reason=reason,
            completed_updates=runner.completed_updates,updates_this_allocation=runner.completed_updates-initial,
            new_formal_updates=runner.completed_updates-initial if a.mode=='formal'else 0,
            whole_process_wall_s=time.monotonic()-START,task=task,recipe_sha256=recipe_sha256()))
    except BaseException:
        write_json(a.output/'status.json',dict(status='FAILED',error=traceback.format_exc(),mode=a.mode));raise
    finally:
        stop.set();thread.join(timeout=6)
        if env is not None:env.close()


if __name__=='__main__':main()
