"""Bounded environment qualification and performance measurement. Never formal training.

No resume/teacher options. Saved policies are validation-only and must be discarded
before a separately approved fresh formal run. GPU0 walk / GPU1 rise is the plan.
"""
import argparse,os,time,json,hashlib,threading,subprocess,traceback
from pathlib import Path
from dataclasses import asdict
START=time.monotonic()
ROOT=Path(__file__).resolve().parents[1]

def main():
 p=argparse.ArgumentParser(__doc__);p.add_argument('--skill',choices=['rise','walk'],required=True)
 p.add_argument('--device',required=True);p.add_argument('--num-envs',type=int,choices=[64,8192,16384,20480,24576],default=64)
 p.add_argument('--updates',type=int,default=5);p.add_argument('--output',type=Path,required=True)
 p.add_argument('--training-phase',choices=['foundation','random025','random050','random100','robust'],default='foundation')
 p.add_argument('--rise-head-mixed',action='store_true')
 p.add_argument('--conditional-head-exploration',action='store_true')
 p.add_argument('--standing-head-replay',action='store_true')
 a=p.parse_args();assert 1<=a.updates<=16
 if a.conditional_head_exploration and not a.rise_head_mixed:raise ValueError('Requires mixed head qualification')
 if a.standing_head_replay and not a.conditional_head_exploration:raise ValueError('Requires conditional head qualification')
 a.output.mkdir(parents=True,exist_ok=False)
 def save(name,x):
  path=a.output/name;t=path.with_suffix('.tmp');t.write_text(json.dumps(x,indent=2,default=str,allow_nan=False)+'\n');t.replace(path)
 save('status.json',dict(status='IMPORTING',pid=os.getpid(),skill=a.skill,new_formal_updates=0))
 import torch,numpy as np,warp as wp,onnxruntime as ort
 from mjlab.envs import ManagerBasedRlEnv
 from mjlab.rl import RslRlVecEnvWrapper
 from mjlab.tasks.registry import load_env_cfg,load_rl_cfg,load_runner_cls
 from mjlab_microduck.custom_v2.sim2real import RISE_TASK,WALK_TASK,model_path,configure_batch_size
 from mjlab_microduck.custom_v2.sim2real_learning import KEY,recipe_sha256
 from mjlab_microduck.tasks import mdp
 torch.set_num_threads(2);torch.cuda.set_device(a.device)
 task=RISE_TASK if a.skill=='rise'else WALK_TASK
 from mjlab_microduck.custom_v2.training_phases import configure_phase,STRENGTH
 strength=STRENGTH[a.training_phase]
 MODEL=model_path(a.skill,a.training_phase)
 cfg=load_env_cfg(task);cfg.seed=2026102101
 agent=load_rl_cfg(task);agent.seed=cfg.seed;agent.logger='tensorboard';agent.upload_model=False
 phase_settings=configure_phase(cfg,a.training_phase)
 if a.rise_head_mixed:
  from mjlab_microduck.custom_v2.head_mixed import configure,course_record
  configure(cfg,course_record(start_reference_step=0))
 if a.conditional_head_exploration:
  from mjlab_microduck.custom_v2.head_conditional_exploration import configure as conditional,allocation_record
  allocation=allocation_record(start_reference_step=0)
  if a.standing_head_replay:
   from mjlab_microduck.custom_v2.head_standing_replay import replay_record
   allocation['standing_replay']=replay_record()
  conditional(cfg,agent,allocation)
 batch_contract=configure_batch_size(cfg,agent,a.num_envs)
 save('resolved-config.json',dict(task=task,env=asdict(cfg),agent=asdict(agent),batch_contract=batch_contract))
 paths=[*ROOT.glob('src/**/*.py'),*ROOT.glob('src/mjlab_microduck/custom_v2/assets/*.json'),MODEL,Path(__file__)]
 hashes={str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest()for x in paths}
 save('source-sha256.json',hashes)
 gpu=[];stop=threading.Event();gpu_index=a.device.split(':')[-1]
 def monitor():
  while not stop.is_set():
   try:
    line=subprocess.check_output(['nvidia-smi','-i',gpu_index,'--query-gpu=utilization.gpu,memory.used,power.draw','--format=csv,noheader,nounits'],text=True,timeout=5).strip()
    util,memory,power=map(float,line.split(','));gpu.append(dict(elapsed_s=time.monotonic()-START,utilization_percent=util,memory_MiB=memory,power_W=power))
   except (subprocess.SubprocessError,ValueError):pass
   stop.wait(1.)
 thread=threading.Thread(target=monitor,daemon=True);thread.start()
 env=None;phase='construct'
 try:
  env=ManagerBasedRlEnv(cfg,device=a.device);assert env.sim.use_cuda_graph
  actuator_routes=[]
  for motor in env.scene['robot'].actuators:
   controls=motor._global_ctrl_ids.cpu().tolist()
   actual=[env.sim.mj_model.joint(int(env.sim.mj_model.actuator_trnid[i,0])).name.rsplit('/',1)[-1]for i in controls]
   assert actual==list(motor.target_names),'Compiled actuator routing mismatch'
   actuator_routes.extend(dict(computed_for=name,applied_to=destination,global_ctrl_id=ctrl)for name,destination,ctrl in zip(motor.target_names,actual,controls))
  wrapped=RslRlVecEnvWrapper(env,clip_actions=agent.clip_actions)
  runner=load_runner_cls(task)(wrapped,asdict(agent),str(a.output),a.device)
  actor=runner.alg.get_policy();before=[p.detach().clone()for p in actor.parameters()]
  replay_reset_audit=False
  if a.standing_head_replay:
   from mjlab_microduck.custom_v2.head_standing_replay import place
   ids=torch.arange(8,device=env.device)
   previous=env.sim.data.qpos.clone()
   env._sc0090_recovery.bucket[ids]=0;mdp.sim2real_state(env)['balance_spawn'][ids]=False
   env.sim.data.qpos[ids,3:7]=env.sim.data.qpos.new_tensor([1.,0.,0.,0.])
   place(env,ids,1.)
   neutral=env._sim2real_pose_bank[env._sim2real_pose_rows_2d[0,0]].expand(8,-1).clone()
   neutral[:,:3]+=env.scene.env_origins[ids]
   torch.testing.assert_close(env.sim.data.qpos[ids],neutral,atol=1e-6,rtol=0)
   assert torch.equal(env.sim.data.qpos[8:],previous[8:])
   assert not env.sim.data.qvel[ids].any()
   assert env._sim2real_standing_replay_mask[ids].all()
   env.reset();replay_reset_audit=True
  snapshots=[];calls=[0];native_reward=env.reward_manager.compute
  def reward(dt):
   value=native_reward(dt);s=mdp.sim2real_measure(env)
   if a.rise_head_mixed:
    term=env.reward_manager.get_term_cfg('head_pose_tracking')
    assert term.weight==3. and term.params['fine_std']==.18 and 'precision_scale'not in term.params
    assert env.reward_manager.get_term_cfg('head_pose_bias').weight==.5
    command=env.command_manager.get_term('head_pose').cfg
    assert command.zero_command_prob==.6 and command.mid_probability==.75 and command.precision_probability==0.
   if calls[0] in (0,24,96):
    snapshots.append({k:v[:16].clone()for k,v in s.items()if isinstance(v,torch.Tensor)and v.shape[:1]==(env.num_envs,)})
   calls[0]+=1;return value
  env.reward_manager.compute=reward
  peak=torch.zeros((),device=a.device,dtype=torch.int32);native_step=env.sim.step
  nacon=wp.to_torch(env.sim.wp_data.nacon);capacity=env.sim.wp_data.naconmax
  def physics():
   native_step();peak.copy_(torch.maximum(peak,nacon.max().to(peak)))
   torch._assert_async((nacon<=capacity).all(),'Contact buffer capacity exceeded')
  env.sim.step=physics
  updates=[];timing=[];native_update=runner.alg.update;native_log=runner.logger.log;last=[time.monotonic()]
  def update():
   out=native_update();assert all(np.isfinite(float(v))for v in out.values()),out
   assert all(torch.isfinite(p).all()for p in actor.parameters())
   updates.append({k:float(v)for k,v in out.items()});return out
  runner.alg.update=update
  def log(*args,**kw):
   now=time.monotonic();timing.append(dict(update=len(timing)+1,elapsed_s=now-START,wall_s=now-last[0],collection_s=kw['collect_time'],learning_s=kw['learn_time']));last[0]=now
   native_log(*args,**kw)
  runner.logger.log=log
  env.episode_length_buf[:a.num_envs//2]=env.max_episode_length-1
  # Exercise the ordinary push event within this short check; rise discovery
  # intentionally has zero push strength. Production interval stays 3–6s.
  for timer in env.event_manager._interval_term_time_left:timer[-4:]=0.
  phase='PPO_qualification';save('status.json',dict(status='VALIDATING',pid=os.getpid(),skill=a.skill,new_formal_updates=0))
  learn_start=time.monotonic();last[0]=learn_start
  runner.learn(num_learning_iterations=a.updates,init_at_random_ep_len=False)
  learning_wall=time.monotonic()-learn_start
  assert len(updates)==a.updates and any(not torch.equal(x,p)for x,p in zip(before,actor.parameters()))
  assert runner.alg.terminal_bootstrap_samples>=a.num_envs//2
  phase='terminal_successor_audit'
  observer=env._sc0090_terminal_critic_recorder._observer
  frozen_state={k:v.clone()for k,v in mdp.sim2real_state(env).items()if isinstance(v,torch.Tensor)}
  cpu_rng=torch.get_rng_state().clone();gpu_rng=torch.cuda.get_rng_state(a.device).clone()
  live_q=env.sim.data.qpos.clone();live_wrench=env.sim.data.xfrc_applied.clone()
  with torch.inference_mode():
   fast=observer.capture(env);full=observer.capture(env,force_full=True)
  torch.testing.assert_close(fast,full,atol=2e-6,rtol=2e-6)
  assert torch.equal(cpu_rng,torch.get_rng_state())and torch.equal(gpu_rng,torch.cuda.get_rng_state(a.device))
  assert torch.equal(live_q,env.sim.data.qpos)and torch.equal(live_wrench,env.sim.data.xfrc_applied)
  for k,v in frozen_state.items():assert torch.equal(v,mdp.sim2real_state(env)[k]),k
  # Verify ordinary partial-reset after inference-mode measurement and another
  # inference pass at the same clock. New state is safe across both contexts.
  phase='partial_reset'
  with torch.inference_mode():mdp.sim2real_measure(env)
  robot=env.scene['robot'];bias_before=robot.data.encoder_bias.clone()
  armature_before=env.sim.model.dof_armature.clone()
  friction_before=[act.friction_scale.clone()for act in robot.actuators]
  assert len(robot.actuators)==1 and len(robot.actuators[0].target_names)==15
  compiled=env.sim.mj_model
  assert bool(compiled.actuator_ctrllimited.all())and bool(compiled.actuator_forcelimited.all())
  assert np.all(compiled.actuator_ctrlrange[:,0]<0)and np.all(compiled.actuator_ctrlrange[:,1]>0)
  np.testing.assert_allclose(compiled.actuator_ctrlrange,compiled.actuator_forcerange)
  supply_before=[(act.vin_tensor.clone(),act.vin_drop_resistance.clone())for act in robot.actuators]
  effective_before=[act._bam_model.actuator.vin.clone()for act in robot.actuators]
  delay_lags=[act._delay_buffer.current_lags.clone()if act._delay_buffer is not None
      else torch.zeros(a.num_envs,device=a.device,dtype=torch.long)for act in robot.actuators]
  kept=mdp.sim2real_state(env)['force_age'][a.num_envs//2:].clone()
  obs,_=env.reset(env_ids=torch.arange(a.num_envs//2,device=a.device))
  torch.testing.assert_close(mdp.sim2real_state(env)['force_age'][a.num_envs//2:],kept,atol=0,rtol=0)
  assert obs['actor'].shape==(a.num_envs,61) and torch.isfinite(obs['actor']).all()
  assert not hasattr(env,'_v2_joint_feedback')
  assert torch.equal(robot.data.encoder_bias,bias_before),'Fixed bias changed on episode reset'
  bias_bound=cfg.events['encoder_bias'].params['bias_range'][1]
  assert bool((bias_before.abs()<=bias_bound+1e-8).all())
  assert float(bias_before.std())>.001*strength if strength else not bool(bias_before.any())
  randomization=[]
  for act,old,lags,(voltage,resistance),effective in zip(robot.actuators,friction_before,delay_lags,supply_before,effective_before):
   assert act._bam_model.actuator.max_current==.6
   limit=act._bam_model.actuator.effort_limit_nm
   voltage_max=max(cfg.scene.entities['robot'].articulation.actuators[0].vin_range)
   expected_limit=min(voltage_max*act._bam_model.kt.value/act._bam_model.R.value,.6*act._bam_model.kt.value)
   assert abs(limit-expected_limit)<1e-12
   assert bool((env.sim.data.qfrc_actuator[:,act._dof_ids].abs()<=limit+1e-6).all())
   assert torch.equal(act.vin_tensor,voltage)and torch.equal(act.vin_drop_resistance,resistance)
   vlo,vhi=phase_settings['supply_voltage_v'];rlo,rhi=phase_settings['supply_resistance_ohm']
   assert bool(((voltage>=vlo-1e-6)&(voltage<=vhi+1e-6)).all())
   assert float(voltage.std())>.1*strength if strength else bool((voltage==11.1).all())
   assert bool(((resistance>=rlo-1e-7)&(resistance<=rhi+1e-7)).all())and act.vin_drop_gain is None
   assert bool(((effective>=9.)&(effective<=voltage+1e-5)).all())
   assert bool((act._prev_motor_torque[:a.num_envs//2]==0).all())
   assert bool((act._prev_duty_cycle[:a.num_envs//2]==0).all())
   assert torch.equal(act.friction_scale[a.num_envs//2:],old[a.num_envs//2:])
   assert bool(((act.friction_scale>=1-.1*strength-1e-6)&(act.friction_scale<=1+.1*strength+1e-6)).all())
   assert not torch.equal(act.friction_scale[:a.num_envs//2],old[:a.num_envs//2])if strength else torch.equal(act.friction_scale,old)
   ids=act._dof_ids
   default=env.sim.get_default_field('dof_armature')[ids]
   scale=env.sim.model.dof_armature[:,ids]/default
   assert bool(((scale>=1-.1*strength-1e-5)&(scale<=1+.1*strength+1e-5)).all())
   assert torch.equal(env.sim.model.dof_armature[a.num_envs//2:,ids],armature_before[a.num_envs//2:,ids])
   if act._delay_buffer is not None:
    assert not act._delay_buffer._buffer._buffer.is_inference()
    assert bool((act._delay_buffer.current_lags[:a.num_envs//2]==0).all())
   else:
    assert cfg.scene.entities['robot'].articulation.actuators[0].delay_max_lag==0
   randomization.append(dict(targets=act.target_names,voltage_range=[float(voltage.min()),float(voltage.max())],supply_resistance_ohm=[float(resistance.min()),float(resistance.max())],effective_voltage_range=[float(effective.min()),float(effective.max())],supply_persistent_across_reset=True,friction_range=[float(act.friction_scale.min()),float(act.friction_scale.max())],armature_scale_range=[float(scale.min()),float(scale.max())],sampled_delay_lags=sorted(set(lags.cpu().tolist()))))
  passive=[i for i,name in enumerate(robot.joint_names)if name.startswith('passive_')]
  assert len(passive)==(14 if strength else 0)
  if passive:assert float(robot.data.joint_pos[:a.num_envs//2,passive].abs().max())<1e-7
  phase='export';runner.save(str(a.output/'validation-final.pt'))
  onnx=list(a.output.glob('*.onnx'));assert len(onnx)==1,onnx
  x=obs['actor'][:16].detach().cpu().numpy()
  with torch.inference_mode():y=actor(obs)[:16].cpu().numpy()
  opt=ort.SessionOptions();opt.intra_op_num_threads=opt.inter_op_num_threads=1
  session=ort.InferenceSession(str(onnx[0]),sess_options=opt,providers=['CPUExecutionProvider'])
  ref=np.concatenate([session.run(None,{session.get_inputs()[0].name:v[None]})[0]for v in x])
  np.testing.assert_allclose(y,ref,rtol=2e-5,atol=2e-5)
  phase='checkpoint_restore'
  saved=torch.load(a.output/'validation-final.pt',map_location='cpu',weights_only=False)['infos'][KEY]
  actor_before={k:v.clone()for k,v in actor.state_dict().items()}
  env.common_step_counter+=77
  runner.load(str(a.output/'validation-final.pt'),map_location=a.device)
  assert env.common_step_counter==saved['common_step_counter']
  assert runner.completed_updates==a.updates
  assert env._sim2real_reference_factor==batch_contract['reference_learning_step_factor']
  for k,v in actor.state_dict().items():assert torch.equal(v,actor_before[k]),k
  for k in ('counts','wins','window_counts','window_wins','last_rates'):
   torch.testing.assert_close(mdp.sim2real_state(env)[k].cpu(),saved['curriculum'][k],atol=0,rtol=0)
  torch.save([{k:v.cpu()for k,v in s.items()}for s in snapshots],a.output/'metric-boundaries.pt')
  np.savez(a.output/'onnx-parity.npz',observations=x,actor=y,onnx=ref)
  assert hashes=={str(x.relative_to(ROOT)):hashlib.sha256(x.read_bytes()).hexdigest()for x in paths},'Source mutated during qualification'
  steady=timing[3:];samples=a.num_envs*agent.num_steps_per_env
  start_steady=timing[2]['elapsed_s']if len(timing)>3 else float('inf')
  utilization=[v['utilization_percent']for v in gpu if start_steady<=v['elapsed_s']<=timing[-1]['elapsed_s']]
  total=time.monotonic()-START
  report=dict(status='PASS',allocation_kind='ENVIRONMENT_QUALIFICATION_ONLY',task=task,skill=a.skill,device=a.device,num_envs=a.num_envs,updates=a.updates,
   head_course='rise-head-mixed-coarse-v1'if a.rise_head_mixed else None,
   head_exploration='rise-head-conditioned-exploration-v1'if a.conditional_head_exploration else None,
   head_replay='rise-head-standing-replay-v1'if a.standing_head_replay else None,
   standing_replay_reset_audit=replay_reset_audit,
   batch_contract=batch_contract,rollout_steps=agent.num_steps_per_env,epochs=agent.algorithm.num_learning_epochs,minibatches=agent.algorithm.num_mini_batches,
   control_dt_s=.02,physics_dt_s=.005,diagnostic_controls=samples*a.updates,physical_substeps=samples*a.updates*4,new_formal_updates=0,
   source_sha256=hashes,recipe_sha256=recipe_sha256(),training_phase=a.training_phase,phase_contract=phase_settings,checkpoint_schema=3,checkpoint_restore_verified=True,
   actuator_routes=actuator_routes,actuator_routes_verified=True,
   randomization=randomization,fixed_encoder_bias_preserved_on_reset=True,
   model_sha256=hashlib.sha256(MODEL.read_bytes()).hexdigest(),mass_kg=float(env.sim.mj_model.body_mass.sum()),
   terminal_bootstrap_samples=runner.alg.terminal_bootstrap_samples,terminal_successor_max_abs=float((fast-full).abs().max()),terminal_capture_preserved_live_state_and_rng=True,finite_losses=True,partial_reset_after_inference_pass=True,
   onnx_max_abs=float(abs(y-ref).max()),peak_contacts=int(peak),contact_capacity=int(capacity),physics_cuda_graph=True,
   motor_graph_replays=[x._compute_graph.replays if x._compute_graph else 0 for x in env.scene['robot'].actuators],
   total_wall_s=total,learning_wall_s=learning_wall,end_to_end_controls_per_s=samples*a.updates/total,
   steady_controls_per_s=(len(steady)*samples/sum(v['wall_s']for v in steady))if steady else None,
   steady_physics_substeps_per_s=(len(steady)*samples*4/sum(v['wall_s']for v in steady))if steady else None,
   steady_collection_s=float(np.mean([v['collection_s']for v in steady]))if steady else None,
   steady_learning_s=float(np.mean([v['learning_s']for v in steady]))if steady else None,
   gpu_steady_sample_count=len(utilization),gpu_steady_mean_percent=float(np.mean(utilization))if utilization else None,
   gpu_steady_p50_percent=float(np.median(utilization))if utilization else None,gpu_steady_p95_percent=float(np.quantile(utilization,.95))if utilization else None,
   gpu_peak_memory_MiB=max(v['memory_MiB']for v in gpu),iteration_timing=timing,
   limitation='Startup and finite qualification only; not learned skill success. Discard weights before approved fresh formal training.')
  save('report.json',report);save('status.json',dict(status='PASS',skill=a.skill,new_formal_updates=0,diagnostic_controls=samples*a.updates))
 except BaseException:
  save('status.json',dict(status='FAILED',phase=phase,new_formal_updates=0,error=traceback.format_exc()));raise
 finally:
  stop.set();thread.join(timeout=6);save('gpu-samples.json',gpu)
  if env is not None:env.close()
if __name__=='__main__':main()
