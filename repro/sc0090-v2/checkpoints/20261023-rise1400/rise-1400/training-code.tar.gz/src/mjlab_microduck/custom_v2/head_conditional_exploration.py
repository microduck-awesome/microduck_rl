"""Opt-in preparation only: observation-conditioned coarse neck/pitch exploration.

Not registered in any task. Mean, saved learned std and network keys are unchanged.
All stochastic-density operations inherit one actual Normal distribution; no
post-sampling noise. The current raw61D actor layout is checked explicitly.
"""
import math
import torch
from torch.distributions import Normal
from rsl_rl.models import MLPModel
from rsl_rl.modules.distribution import GaussianDistribution

EXPLORATION_ID='rise-head-conditioned-exploration-v1'


def allocation_record(start_reference_step=7784*48):
    return dict(id=EXPLORATION_ID,start_reference_step=start_reference_step,
                budget_reference_updates=128,maximum_std=.04)


def configure(cfg,agent,allocation):
    from copy import deepcopy
    init=cfg.events['sim2real_initialize'].params
    if init['kind']!='rise' or not init.get('head_repair'):
        raise ValueError('Conditional exploration requires mixed rise head course')
    if (allocation.get('id')!=EXPLORATION_ID or allocation.get('budget_reference_updates')!=128
            or allocation.get('maximum_std')!=.04 or allocation.get('start_reference_step',-1)<0):
        raise ValueError('Invalid conditional exploration allocation')
    init['head_exploration']=deepcopy(allocation)
    agent.actor.class_name='mjlab_microduck.custom_v2.head_conditional_exploration.ConditionalHeadMLP'
    agent.actor.distribution_cfg['class_name']='mjlab_microduck.custom_v2.head_conditional_exploration.ConditionalHeadGaussian'
    agent.actor.distribution_cfg['maximum']=allocation['maximum_std']
    if allocation.get('standing_replay'):
        from .head_standing_replay import configure as configure_replay
        configure_replay(cfg,allocation['standing_replay'])


def observation_floor(raw, maximum=.04):
    if raw.shape[-1]!=61:raise ValueError('Requires raw61D actor observations')
    if not 0<maximum<=.08:raise ValueError('Invalid coarse exploration maximum')
    # proprio6 + left-leg5 -> neck/pitch11:13; command head starts51.
    # This is observed error, including ordinary bias/noise/delay; no truth.
    error=(raw[...,11:13]-raw[...,51:53]).abs()
    fraction=((error-math.radians(2))/math.radians(6)).clamp(0,1)
    floor=raw.new_zeros((*raw.shape[:-1],14))
    floor[...,5:7]=maximum*fraction
    return floor


class ConditionalHeadGaussian(GaussianDistribution):
    def __init__(self,output_dim,init_std=1.,std_type='scalar',maximum=.04):
        if output_dim!=14:raise ValueError('Requires14 policy actions')
        super().__init__(output_dim,init_std,std_type)
        self.maximum=maximum
        self._conditional_floor=None

    def set_observation(self,raw):
        self._conditional_floor=observation_floor(raw,self.maximum).detach()

    def update(self,mlp_output):
        if self._conditional_floor is None or self._conditional_floor.shape!=mlp_output.shape:
            raise ValueError('Set matching raw observation before every distribution update')
        std=(self.std_param if self.std_type=='scalar'else self.log_std_param.exp()).expand_as(mlp_output)
        self._distribution=Normal(mlp_output,torch.maximum(std,self._conditional_floor))


class ConditionalHeadMLP(MLPModel):
    def __init__(self,*args,**kwargs):
        super().__init__(*args,**kwargs)
        if self.obs_dim!=61 or not isinstance(self.distribution,ConditionalHeadGaussian):
            raise ValueError('ConditionalHeadMLP requires raw61D and ConditionalHeadGaussian')

    def get_latent(self,obs,masks=None,hidden_state=None):
        raw=torch.cat([obs[group]for group in self.obs_groups],dim=-1)
        self.distribution.set_observation(raw)
        return super().get_latent(obs,masks,hidden_state)
