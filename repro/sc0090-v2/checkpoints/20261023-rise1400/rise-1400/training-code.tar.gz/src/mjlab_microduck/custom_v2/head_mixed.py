"""Explicitly budgeted coarse head repair; old polish accounting stays intact."""
from copy import deepcopy

COURSE_ID='rise-head-mixed-coarse-v1'
BUDGET_REFERENCE_UPDATES=512
START_UPDATE=7528


def course_record(start_reference_step=START_UPDATE*24*2):
    return dict(id=COURSE_ID,stage='coarse',start_reference_step=start_reference_step,
                budget_reference_updates=BUDGET_REFERENCE_UPDATES,
                head_absolute_band_deg=2.,authorization='user approved 256 actual /512 reference updates')


def configure(cfg,course):
    init=cfg.events['sim2real_initialize'].params
    if init['kind']!='rise' or init.get('training_phase')!='robust':
        raise ValueError('Mixed head repair is rise/robust only')
    if course['id']!=COURSE_ID or course['stage']!='coarse' or course['budget_reference_updates']!=512:
        raise ValueError('Only the bounded coarse head stage is authorized')
    init['head_repair']=deepcopy(course)
    set_terms(cfg.rewards['head_pose_tracking'],cfg.rewards['head_pose_bias'],cfg.commands['head_pose'])


def set_terms(tracking,bias,command):
    tracking.weight=3.
    tracking.params.update(std=.5,fine_std=.18,fine_weight=.5)
    tracking.params.pop('precision_scale',None)
    bias.weight=.5
    command.zero_command_prob=.6
    command.precision_probability=0.
    command.mid_probability=.75
    command.mid_limit=.1


def apply_live(env):
    if not getattr(env,'_sim2real_head_repair',None):return False
    set_terms(env.reward_manager.get_term_cfg('head_pose_tracking'),
              env.reward_manager.get_term_cfg('head_pose_bias'),
              env.command_manager.get_term('head_pose').cfg)
    return True
