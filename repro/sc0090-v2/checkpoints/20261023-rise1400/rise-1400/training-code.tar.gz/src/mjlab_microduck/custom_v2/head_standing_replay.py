"""Opt-in contact-consistent HOME rehearsal inside the existing standing bucket.

Half the standing bucket stays randomized. The seven bucket probabilities,
40% tilt trials, physical randomization, commands and rewards stay unchanged.
"""
import torch

REPLAY_ID = 'rise-head-standing-replay-v1'


def replay_record():
    return dict(id=REPLAY_ID, fraction_in_standing_bucket=.5)


def configure(cfg, allocation):
    if allocation != replay_record():
        raise ValueError('Only half-standing HOME replay is qualified')
    cfg.events['set_ground_state'].params['standing_replay_fraction'] = .5


def contact_pose(neutral, original, origins):
    """Rotate the declared contact pose into each original random yaw."""
    result = neutral.expand(len(original), -1).clone()
    w, x, y, z = original[:, 3:7].unbind(-1)
    yaw = torch.atan2(2 * (w * z + x * y), 1 - 2 * (y.square() + z.square()))
    c, s = yaw.cos(), yaw.sin()
    px, py = neutral[0], neutral[1]
    result[:, 0] = c * px - s * py
    result[:, 1] = s * px + c * py
    result[:, :3] += origins
    c, s = (yaw / 2).cos(), (yaw / 2).sin()
    w, x, y, z = neutral[3:7].unbind(-1)
    result[:, 3:7] = torch.stack((c*w-s*z, c*x-s*y, c*y+s*x, c*z+s*w), -1)
    return result


def place(env, env_ids, fraction):
    if not 0 <= fraction <= 1:
        raise ValueError('Invalid standing replay fraction')
    if fraction == 0:
        return  # Preserve the legacy RNG stream exactly.
    from mjlab_microduck.tasks import mdp
    state = mdp.sim2real_state(env)
    if not hasattr(env, '_sim2real_standing_replay_mask'):
        with torch.inference_mode(False):
            env._sim2real_standing_replay_mask = torch.zeros(env.num_envs, dtype=torch.bool, device=env.device)
    env._sim2real_standing_replay_mask[env_ids] = False
    eligible = env_ids[(env._sc0090_recovery.bucket[env_ids] == 0) & ~state['balance_spawn'][env_ids]]
    chosen = eligible[torch.rand(len(eligible), device=env.device) < fraction]
    if not len(chosen):
        return
    neutral = env._sim2real_pose_bank[env._sim2real_pose_rows_2d[0, 0]]
    env.sim.data.qpos[chosen] = contact_pose(neutral, env.sim.data.qpos[chosen], env.scene.env_origins[chosen])
    env.sim.data.qvel[chosen] = 0
    env._sim2real_standing_replay_mask[chosen] = True
    # No fabricated holds/wins, gate changes or removal from ordinary forces.
