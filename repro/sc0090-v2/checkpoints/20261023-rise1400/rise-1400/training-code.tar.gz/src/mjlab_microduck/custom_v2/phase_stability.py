"""Evidence for a difficulty transition, separate from the physical skill recipe.

400 reference updates is a bounded engineering exposure floor, not a PPO optimum.
At N16384 this is 200 actual updates. User-approved >=95% mastery bypasses
this exposure floor; other passes need sustained exposure and two checkpoints.
"""
MIN_REFERENCE_UPDATES=400
ASSESSMENT_REFERENCE_GAP=100


def high_success_rate(decision):
    """User-authorized >=95% overall frozen two-seed recovery shortcut.

    The original per-pose/per-seed mastery criteria still apply; total score
    alone cannot admit an unmastered pose or insufficient sample coverage.
    """
    if not(decision.get('motion_mastered')and decision.get('sufficient_coverage')):return False
    counts=decision.get('counts',{})
    if set(counts)!={'standing','sitting','prone','frontier','left_side','right_side','supine'}:return False
    if any(not isinstance(v,(list,tuple))or len(v)!=2 or
           type(v[0])is not int or type(v[1])is not int or not 0<=v[1]<=v[0] or v[0]<256
           for v in counts.values()):return False
    return sum(v[1]for v in counts.values())/sum(v[0]for v in counts.values())>=.95


def phase_start_update(record):
    phase=record['training_phase']
    if phase=='foundation':return 0
    for item in reversed(record.get('migration_history',[])):
        if item.get('target_training_phase')==phase and item.get('source_training_phase')!=phase:
            return item['completed_updates']
    raise ValueError('Difficulty exposure needs the recorded phase entry, not resume time')


def record_assessment(record,decision,previous):
    phase=record['training_phase'];start=phase_start_update(record)
    factor=record['batch_contract']['reference_learning_step_factor']
    current=decision['last_iteration']
    if factor<=0 or current<start:raise ValueError('Invalid phase exposure clock')
    passed=bool(decision.get('motion_mastered')and decision.get('sufficient_coverage')
                and decision.get('training_phase')==phase)
    prior=previous.get('phase_stability',{})
    same_phase=(previous.get('training_phase')==phase and previous.get('last_iteration',-1)>=start
                and prior.get('phase_start_update',start)==start)
    distinct=(same_phase and current>previous.get('last_iteration',-1)
              and (current-previous.get('last_iteration',-1))*factor>=ASSESSMENT_REFERENCE_GAP
              and decision.get('checkpoint_sha256')!=previous.get('checkpoint_sha256'))
    prior_pass=bool(previous.get('motion_mastered')and previous.get('sufficient_coverage'))
    # The saved preceding report can contribute one genuine pass even if it
    # predates this bookkeeping repair. It can never manufacture a second one.
    count=0
    if passed:
        count=1
        if distinct and prior_pass:
            count=min(2,prior.get('consecutive_mastered',1)+1)
    progress=(current-start)*factor
    decision['phase_stability']=dict(phase=phase,phase_start_update=start,
        actual_updates_in_phase=current-start,reference_updates_in_phase=progress,
        minimum_reference_updates=MIN_REFERENCE_UPDATES,consecutive_mastered=count,
        required_consecutive_mastered=2,direct_success_threshold=.95,
        direct_success_pass=high_success_rate(decision),
        ready=bool(passed and(high_success_rate(decision)or(progress>=MIN_REFERENCE_UPDATES and count>=2))))
    return decision
