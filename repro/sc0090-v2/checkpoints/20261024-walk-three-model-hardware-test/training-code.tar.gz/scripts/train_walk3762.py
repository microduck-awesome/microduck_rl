"""Bounded official PPO allocations; frozen 3762 physics, no recovery curriculum."""
import argparse, hashlib, importlib.metadata, json, math, os, random, signal, subprocess, time
from dataclasses import asdict
from pathlib import Path
import numpy as np
import torch
import warp as wp
import mjlab.tasks
from mjlab.envs import ManagerBasedRlEnv
from mjlab.rl import RslRlVecEnvWrapper
from mjlab.tasks.registry import load_env_cfg, load_rl_cfg, load_runner_cls
from mjlab_microduck.custom_v2.walking3762 import TASK
from mjlab_microduck.custom_v2.microduck_v2 import ASSETS, POLICY_JOINTS


def write_json(path,value):
    temp=path.with_suffix('.tmp');temp.write_text(json.dumps(value,default=str,indent=2)+'\n');temp.replace(path)


def main():
    p=argparse.ArgumentParser(__doc__)
    p.add_argument('--output',type=Path,required=True)
    p.add_argument('--preflight',type=Path,required=True)
    p.add_argument('--iterations',type=int,default=250)
    p.add_argument('--num-envs',type=int,default=4096)
    p.add_argument('--device',default='cuda:0')
    p.add_argument('--resume',type=Path)
    p.add_argument('--validation-only',action='store_true')
    p.add_argument('--transition-manifest',type=Path)
    a=p.parse_args();assert a.iterations>0
    proof=json.loads(a.preflight.read_text())
    assert proof['status']=='PASS' and proof['task']==TASK
    assert proof['envs']==a.num_envs
    assert proof['robot_xml_sha256']==hashlib.sha256((ASSETS/'robot.xml').read_bytes()).hexdigest()
    if not a.validation_only:
        assert a.num_envs==4096 and proof['throughput']['measured_updates']>=10
    a.output.mkdir(parents=True,exist_ok=False)
    root=Path(__file__).resolve().parents[1]
    hashes={str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest()
            for folder in ('src','scripts') for f in (root/folder).rglob('*')
            if (folder=='src' or f.name in ('train_walk3762.py','v2_python.sh')) and f.is_file() and '__pycache__' not in str(f) and f.suffix in ('.py','.cpp','.xml','.json','.npz','.npy','.stl')}
    torch.set_num_threads(2)
    cfg=load_env_cfg(TASK);cfg.seed=20261024;cfg.scene.num_envs=a.num_envs
    agent=load_rl_cfg(TASK);agent.logger='tensorboard';agent.upload_model=False;agent.seed=cfg.seed
    agent.save_interval=250
    write_json(a.output/'run.json',dict(task=TASK,source_sha256=hashes,agent=asdict(agent),environment=asdict(cfg),
        git_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        dependencies={n:importlib.metadata.version(n)for n in ('torch','mjlab','mujoco','mujoco-warp','rsl-rl-lib')},
        preflight=str(a.preflight),resume=str(a.resume),validation_only=a.validation_only,
        resume_semantics='native-new-episodes; learning state and RNG restored; physics snapshot diagnostic only'))
    stopping=False
    def stop(*_):
        nonlocal stopping
        stopping=True
    signal.signal(signal.SIGTERM,stop);signal.signal(signal.SIGINT,stop)
    env=ManagerBasedRlEnv(cfg,device=a.device)
    completed=0;last_checkpoint=None
    class StopRequested(Exception):pass
    try:
        assert env.sim.use_cuda_graph
        counts=wp.to_torch(env.sim.wp_data.nacon);native_physics=env.sim.step
        def physics():
            native_physics()
            torch._assert_async((counts<=env.sim.wp_data.naconmax).all(),'contact capacity exceeded')
        env.sim.step=physics
        wrapped=RslRlVecEnvWrapper(env,clip_actions=agent.clip_actions)
        runner=load_runner_cls(TASK)(wrapped,asdict(agent),str(a.output),a.device)
        if a.resume:
            infos=runner.load(str(a.resume));record=infos['walk3762'];completed=record['completed_updates']
            transition=None
            if record['source_sha256']!=hashes:
                assert a.transition_manifest is not None,'Training source changed; requires explicit transition'
                transition=json.loads(a.transition_manifest.read_text())
                assert transition['parent_checkpoint_sha256']==hashlib.sha256(a.resume.read_bytes()).hexdigest()
                assert transition['from_source_sha256']==record['source_sha256']
                assert transition['to_source_sha256']==hashes
                assert transition['status'] in ('VALIDATED_GEOMETRY_AND_OFFICIAL_WALK_DR_TRANSITION','VALIDATED_HEAD_ROLL_CLEARANCE_TRANSITION','VALIDATED_SUBSTEP_CONTACT_TRANSITION','VALIDATED_VELOCITY_BIAS_TRANSITION','VALIDATED_ALL14_CLEARANCE_TRANSITION','VALIDATED_ANTICIPATORY_CLEARANCE_TRANSITION')
            elif a.transition_manifest is not None:
                transition=json.loads(a.transition_manifest.read_text())
                assert transition['parent_checkpoint_sha256']==hashlib.sha256(a.resume.read_bytes()).hexdigest()
            assert record['num_envs']==a.num_envs
            torch.set_rng_state(record['rng']['cpu'].cpu())
            cuda_states=record['rng']['cuda']
            if len(cuda_states)!=torch.cuda.device_count():
                assert transition is not None and torch.cuda.device_count()==1
                assert os.environ.get('CUDA_VISIBLE_DEVICES')==transition['gpu_migration']['target_uuid']
                cuda_states=[cuda_states[transition['gpu_migration']['source_rng_index']]]
            torch.cuda.set_rng_state_all([v.cpu()for v in cuda_states])
            np.random.set_state(record['rng']['numpy']);random.setstate(record['rng']['python'])
            env._v2_error_blocks.rng.set_state(record['rng']['paired'].cpu())
            expected=torch.load(a.resume,map_location='cpu',weights_only=False)
            def equal(actual,wanted):
                if isinstance(wanted,torch.Tensor):assert torch.equal(actual.detach().cpu(),wanted)
                elif isinstance(wanted,dict):
                    assert actual.keys()==wanted.keys()
                    for key in wanted:equal(actual[key],wanted[key])
                elif isinstance(wanted,(list,tuple)):
                    assert len(actual)==len(wanted)
                    for x,y in zip(actual,wanted):equal(x,y)
                else:assert actual==wanted
            restored=runner.alg.save()
            for key in ('actor_state_dict','critic_state_dict','optimizer_state_dict'):equal(restored[key],expected[key])
            runner.alg.learning_rate=runner.alg.optimizer.param_groups[0]['lr']
            assert env.common_step_counter==infos['env_state']['common_step_counter']
            runner.current_learning_iteration=completed
            env.reset()
            write_json(a.output/'resume-verification.json',dict(status='PASS',completed_updates=completed,
                transition_manifest=str(a.transition_manifest)if a.transition_manifest else None,cuda_rng_streams_restored=len(cuda_states),restored_clock=env.common_step_counter,actor_critic_normalizers_optimizer_exact=True,learning_rate=runner.alg.learning_rate,semantics='native-new-episodes',physics_exact=False))
        from mjlab_microduck.custom_v2.head_geometry import project_head_targets
        head=env.command_manager.get_term('head_pose')
        torch.testing.assert_close(head.command,project_head_targets(head.requested),atol=2e-7,rtol=2e-7)
        push=env.event_manager.get_term_cfg('push_robot')
        assert push.params['velocity_range']=={'x':(-.3,.3),'y':(-.3,.3)}
        assert push.interval_range_s==(3.,6.)
        write_json(a.output/'geometry-runtime-verification.json',dict(status='PASS',
            samples=env.num_envs,clock=env.common_step_counter,
            projected_samples=int((head.command-head.requested).abs().amax(-1).gt(1e-7).sum()),
            push_velocity_range=push.params['velocity_range'],push_interval_s=push.interval_range_s))
        if 'joint_clearance' in env.reward_manager.active_terms:
            guard = env.reward_manager.get_term_cfg('joint_clearance')
            ids, names = env.scene['robot'].find_joints(POLICY_JOINTS, preserve_order=True)
            assert tuple(names) == POLICY_JOINTS and len(set(ids)) == 14
            assert list(guard.params['asset_cfg'].joint_ids) == list(ids)
            assert guard.weight == -1.0 and guard.params['margin_rad'] == math.radians(4.)
            assert guard.params['horizon_s'] == 0.04
            assert 'head_roll_clearance' not in env.reward_manager.active_terms
            write_json(a.output/'joint-clearance-runtime-verification.json', dict(
                status='PASS', names=names, joint_ids=ids, weight=guard.weight,
                margin_rad=guard.params['margin_rad'], horizon_s=guard.params['horizon_s'], mouth_excluded='mouth' not in names))
        start=completed;assert start+a.iterations<=agent.max_iterations or a.validation_only
        native_save=runner.save
        def save(_path=None,infos=None):
            nonlocal last_checkpoint
            path=a.output/f'checkpoint_{completed:06d}.pt'
            rng=dict(cpu=torch.get_rng_state(),cuda=torch.cuda.get_rng_state_all(),numpy=np.random.get_state(),
                     python=random.getstate(),paired=env._v2_error_blocks.rng.get_state())
            record=dict(completed_updates=completed,num_envs=a.num_envs,source_sha256=hashes,rng=rng,
                        physics_resume='native-new-episodes',validation_only=a.validation_only)
            old=runner.current_learning_iteration;runner.current_learning_iteration=completed
            temp=a.output/f'.checkpoint_{completed:06d}.pt'
            native_save(str(temp),{**(infos or {}),'walk3762':record})
            temp.replace(path);runner.current_learning_iteration=old
            # Preserve actual boundary physics/motor state for diagnosis, without
            # pretending these selected fields implement complete simulation restore.
            diagnostic=dict(common_step_counter=env.common_step_counter,
                physics={n:getattr(env.sim.data,n).detach().cpu()for n in ('qpos','qvel','ctrl','qacc_warmstart')},
                paired={k:v.detach().cpu()for k,v in vars(env._v2_error_blocks).items()if isinstance(v,torch.Tensor)},
                motors=[{k:v.detach().cpu()for k,v in vars(m).items()if isinstance(v,torch.Tensor)}for m in env.scene['robot'].actuators])
            if 'velocity_bias' in env.reward_manager.active_terms:
                bias=env.reward_manager.get_term_cfg('velocity_bias').func
                diagnostic['velocity_bias']=dict(last_step=bias.last_step,
                    tensors={k:v.detach().cpu()for k,v in vars(bias).items()if isinstance(v,torch.Tensor)})
            torch.save(diagnostic,a.output/f'boundary_{completed:06d}.pt')
            last_checkpoint=str(path)
        # Native save cadence is zero-based. Use completed update counts.
        runner.save=lambda *args,**kwargs:None
        native_update=runner.alg.update
        def update():
            nonlocal completed
            result=native_update();completed+=1
            assert all(math.isfinite(float(v))for v in result.values()),result
            assert all(torch.isfinite(v).all()for v in runner.alg.get_policy().parameters())
            if completed%250==0:save()
            if completed%10==0 or completed<=start+5:
                write_json(a.output/'status.json',dict(status='RUNNING',pid=os.getpid(),completed_updates=completed,
                    allocation_end=start+a.iterations,controls=completed*a.num_envs*agent.num_steps_per_env,
                    clock=env.common_step_counter,losses=result,updated_unix=time.time(),checkpoint=last_checkpoint))
            if stopping:raise StopRequested()
            return result
        runner.alg.update=update
        try:runner.learn(a.iterations,init_at_random_ep_len=True)
        except StopRequested:pass
        save()
        write_json(a.output/'status.json',dict(status='STOPPED'if stopping else'ALLOCATION_COMPLETE',pid=os.getpid(),
            completed_updates=completed,controls=completed*a.num_envs*agent.num_steps_per_env,
            checkpoint=last_checkpoint,goal_complete=False,updated_unix=time.time()))
    except BaseException as exc:
        write_json(a.output/'status.json',dict(status='FAILED',pid=os.getpid(),completed_updates=completed,
            error=repr(exc),checkpoint=last_checkpoint,updated_unix=time.time()))
        raise
    finally:env.close()

if __name__=='__main__':main()
