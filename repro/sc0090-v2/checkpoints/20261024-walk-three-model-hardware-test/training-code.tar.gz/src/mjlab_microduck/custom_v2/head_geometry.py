"""Shared geometry-derived head target adapter; physical robot assets are unchanged."""
from dataclasses import dataclass
import json
from pathlib import Path
import torch
from mjlab_microduck.tasks.mdp import UniformPoseCommand, UniformPoseCommandCfg

ENVELOPE_PATH=Path(__file__).with_name('head-command-envelope.json')
ENVELOPE=json.loads(ENVELOPE_PATH.read_text())


def project_head_targets(requested):
    """Closest point in the validated coupled-pitch half-space after axis clipping.

    No learned parameters; yaw/roll remain unchanged. Training and assessment
    consume this same effective target. Callers retain original requests separately.
    """
    q=torch.maximum(torch.minimum(requested,requested.new_tensor(ENVELOPE['upper'])),requested.new_tensor(ENVELOPE['lower']))
    k=ENVELOPE['neck_coefficient'];bound=ENVELOPE['minimum_coupled_pitch']
    delta=torch.relu(bound-k*q[...,0]-q[...,1])/(k*k+1.)
    return torch.stack((q[...,0]+k*delta,q[...,1]+delta,q[...,2],q[...,3]),dim=-1)


class GeometryHeadCommand(UniformPoseCommand):
    def __init__(self,cfg,env):
        super().__init__(cfg,env)
        self.requested=torch.zeros_like(self._command)
    def _resample_command(self,env_ids):
        super()._resample_command(env_ids)
        self.requested[env_ids]=self._command[env_ids]
        self._command[env_ids]=project_head_targets(self._command[env_ids])


@dataclass(kw_only=True)
class GeometryHeadCommandCfg(UniformPoseCommandCfg):
    def build(self,env):
        return GeometryHeadCommand(self,env)
