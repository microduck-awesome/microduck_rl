"""Physical policy-joint clearance cost for the frozen collision model."""
import torch


def joint_clearance_cost(env, asset_cfg, margin_rad, horizon_s=0.0):
    """Nonnegative squared hinge inside the hard-limit margin; zero outside.

    Uses physical joint position, not the noisy paired actor observation. It
    does not clamp actions, change requested targets, or alter physical limits.
    """
    robot = env.scene[asset_cfg.name]
    q = robot.data.joint_pos[:, asset_cfg.joint_ids]
    limits = robot.data.joint_pos_limits[:, asset_cfg.joint_ids]
    clearance = torch.minimum(q - limits[..., 0], limits[..., 1] - q)
    cost = torch.square(torch.clamp(1.0 - clearance / margin_rad, min=0.0))
    assert horizon_s >= 0.0
    if horizon_s > 0.0:
        # Reward-only constant-velocity warning, not an action filter or a
        # claimed braking model. Never forgive an existing physical violation.
        predicted = q + horizon_s * robot.data.joint_vel[:, asset_cfg.joint_ids]
        predicted_clearance = torch.minimum(predicted - limits[..., 0], limits[..., 1] - predicted)
        predicted_cost = torch.square(torch.clamp(1.0 - predicted_clearance / margin_rad, min=0.0))
        cost = torch.maximum(cost, predicted_cost)
    return cost.sum(-1)


# Retain the historical callable for diagnostic scripts.
head_roll_clearance_cost = joint_clearance_cost
