"""Preserve self-contact coverage across the existing four physics substeps."""
import torch


class SelfContactWindow:
    """Native metrics term with episode reset support; does not write physics."""
    def __init__(self, cfg, env):
        self.sensor_name = cfg.params['sensor_name']
        self.sensor = env.scene.sensors[self.sensor_name]
        found = self.sensor.data.found
        assert found is not None
        self.values = torch.zeros_like(found)
        self.step = None
        env._walk_self_contact_window = self

    def __call__(self, env, sensor_name):
        assert sensor_name == self.sensor_name
        if self.step != env.common_step_counter:
            self.values.zero_()
            self.step = env.common_step_counter
        found = self.sensor.data.found
        torch.maximum(self.values, found, out=self.values)
        return found.sum(dim=-1).float()

    def reset(self, env_ids=None):
        self.values[slice(None) if env_ids is None else env_ids] = 0


def substep_self_collision_cost(env, sensor_name):
    window = env._walk_self_contact_window
    assert window.sensor_name == sensor_name
    # The native environment increments this counter after the substep loop,
    # then computes rewards, then resets terminated worlds through the managers.
    assert window.step == env.common_step_counter - 1
    return window.values.sum(dim=-1).float()
