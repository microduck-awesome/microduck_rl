"""Bounded sustained velocity-error cost; original instantaneous rewards remain."""
import math
import torch


class VelocityBiasCost:
    def __init__(self, cfg, env):
        self.ema_error = torch.zeros(env.num_envs, 3, device=env.device)
        self.previous_command = torch.zeros_like(self.ema_error)
        self.cached_cost = torch.zeros(env.num_envs, device=env.device)
        self.last_step = None

    def __call__(self, env, command_name, asset_cfg, tau_s, linear_scale, yaw_scale):
        assert tau_s > 0 and linear_scale > 0 and yaw_scale > 0
        if self.last_step == env.common_step_counter:
            return self.cached_cost
        command = env.command_manager.get_command(command_name)
        robot = env.scene[asset_cfg.name]
        actual = torch.cat((robot.data.root_link_lin_vel_b[:, :2],
                            robot.data.root_link_ang_vel_b[:, 2:3]), dim=-1)
        changed = (command != self.previous_command).any(-1)
        self.ema_error.masked_fill_(changed[:, None], 0.)
        alpha = -math.expm1(-env.step_dt / tau_s)
        self.ema_error.lerp_(actual - command, alpha)
        self.previous_command.copy_(command)
        xy = self.ema_error[:, :2].square().sum(-1) / linear_scale**2
        yaw = self.ema_error[:, 2].square() / yaw_scale**2
        self.cached_cost.copy_(-torch.expm1(-xy) - torch.expm1(-yaw))
        self.last_step = env.common_step_counter
        return self.cached_cost

    def reset(self, env_ids=None):
        ids = slice(None) if env_ids is None else env_ids
        self.ema_error[ids] = 0.
        self.previous_command[ids] = 0.
        self.cached_cost[ids] = 0.
