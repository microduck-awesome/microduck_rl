"""Official Velocity learning with the frozen paired3762 collision physics."""
from copy import deepcopy

TASK = 'Mjlab-Velocity-Flat-MicroDuck-V2-Paired3762-Collision'
RISE = 'Mjlab-StandUp-Flat-MicroDuck-V2-PairedError-Baseline'


def nonfoot_floor_contact(env):
    found = env.scene.sensors['nonfoot_floor_contact'].data.found
    return found.reshape(env.num_envs, -1).bool().any(-1)


def make_cfg(play=False):
    from mjlab.tasks.registry import load_env_cfg
    from .microduck_v2 import make_v2_baseline_env_cfg
    from .paired_randomization import configure
    from .training import _replace_standing_height

    cfg = configure(make_v2_baseline_env_cfg(play))
    rise = load_env_cfg(RISE, play=play)
    cfg.scene.entities['robot'] = deepcopy(rise.scene.entities['robot'])
    cfg.sim = deepcopy(rise.sim)
    cfg.decimation = rise.decimation
    from .head_geometry import GeometryHeadCommandCfg
    cfg.commands["head_pose"] = GeometryHeadCommandCfg(**vars(cfg.commands["head_pose"]))
    # Keep the official Velocity event stack, including +/-0.3 m/s pushes.
    # The baseline factory already replaces only incompatible XL330 motor DR;
    # paired configure replaces q/v error and voltage with the 3762 recipe.
    cfg.events['v2_reset_joint_guards'] = deepcopy(rise.events['v2_reset_joint_guards'])
    for term in cfg.rewards.values():
        _replace_standing_height(term.params)
    # Full-body collision permits stable hip/head support below the stock 70deg
    # fall threshold. Locomotion must end on non-foot floor contact; the robot
    # and paired DR remain exactly those of the released rise policy.
    from mjlab.sensor import ContactSensorCfg, ContactMatch
    from mjlab.managers import TerminationTermCfg
    cfg.scene.sensors = (*cfg.scene.sensors, ContactSensorCfg(
        name='nonfoot_floor_contact',
        primary=ContactMatch(mode='geom', entity='robot',
            pattern=r'^(?!(left_foot_collision|right_foot_collision)$).*collision$'),
        secondary=ContactMatch(mode='body', pattern='terrain'),
        fields=('found',), reduce='none', num_slots=1))
    cfg.terminations['nonfoot_floor_contact'] = TerminationTermCfg(func=nonfoot_floor_contact, time_out=False)
    # Cover every policy joint after upright neck-limit failure. Preserve
    # the previous head-roll contribution, official weights and targets.
    import math
    from mjlab.managers import RewardTermCfg, SceneEntityCfg
    from .head_roll_clearance import joint_clearance_cost
    from .microduck_v2 import POLICY_JOINTS
    cfg.rewards['joint_clearance'] = RewardTermCfg(
        func=joint_clearance_cost, weight=-1.0,
        params={'asset_cfg': SceneEntityCfg('robot', joint_names=POLICY_JOINTS, preserve_order=True),
                'margin_rad': math.radians(4.0), 'horizon_s': 0.04})
    # Preserve the original penalty weight and contact matching, but charge
    # transient contacts from every physics substep, not only the last one.
    from mjlab.managers import MetricsTermCfg
    from .substep_contacts import SelfContactWindow, substep_self_collision_cost
    cfg.metrics['self_contact_substep'] = MetricsTermCfg(
        func=SelfContactWindow, params={'sensor_name': 'self_collision'},
        per_substep=True)
    cfg.rewards['self_collisions'].func = substep_self_collision_cost
    # Add a bounded signal for sustained commanded-speed error. Keep all
    # original instantaneous tracking/stability costs; do not filter actions.
    from .velocity_bias import VelocityBiasCost
    cfg.rewards['velocity_bias'] = RewardTermCfg(
        func=VelocityBiasCost, weight=-1.0,
        params={'command_name': 'twist', 'asset_cfg': SceneEntityCfg('robot'),
                'tau_s': 1.0, 'linear_scale': 0.08, 'yaw_scale': 0.25})
    return cfg


def register():
    from mjlab.tasks.registry import load_rl_cfg, load_runner_cls, register_mjlab_task
    from .microduck_v2 import TASK_ID
    rl = load_rl_cfg(TASK_ID)
    rl.experiment_name = 'walk3762_official'
    rl.run_name = rl.experiment_name
    register_mjlab_task(task_id=TASK, env_cfg=make_cfg(), play_env_cfg=make_cfg(True),
                       rl_cfg=rl, runner_cls=load_runner_cls(TASK_ID))
