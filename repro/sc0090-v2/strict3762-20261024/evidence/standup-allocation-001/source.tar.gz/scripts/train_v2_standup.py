"""Bounded V2 standup allocation with independent, two-seed recovery evaluation."""
import argparse
from dataclasses import asdict
import hashlib
import importlib.metadata
import json
import os
from pathlib import Path
import random
import signal
import subprocess
import tarfile
import time

import numpy as np
import torch
import warp as wp
import mjlab.tasks
from mjlab.envs import ManagerBasedRlEnv
from mjlab.rl import RslRlVecEnvWrapper
from mjlab.tasks.registry import load_env_cfg, load_rl_cfg, load_runner_cls
from mjlab_microduck.custom_v2 import recovery


def write_json(path, value):
    temporary = path.with_suffix(path.suffix + '.tmp')
    temporary.write_text(json.dumps(value, indent=2, default=str) + '\n')
    temporary.replace(path)


def evaluate(task, policy, device, stage, samples):
    cpu_rng, cuda_rng = torch.get_rng_state(), torch.cuda.get_rng_state_all()
    numpy_rng, python_rng = np.random.get_state(), random.getstate()
    was_training = policy.training
    cases = []
    policy.eval()
    try:
        for seed in (2026101501, 2026101502):
            cfg = load_env_cfg(task, play=True)
            cfg.seed, cfg.scene.num_envs = seed, 7 * samples
            cfg.episode_length_s = 8.
            cfg.curriculum, cfg.rewards, cfg.terminations = {}, {}, {}
            cfg.events = {n:t for n,t in cfg.events.items() if n in {
                'expand_bam_friction_fields','v2_runtime','mouth_reset','mouth_hold',
                'reset_base','set_ground_state','v2_reset_joint_guards'}}
            cfg.events['set_ground_state'].params['evaluation_buckets'] = True
            cfg.observations['actor'].enable_corruption = False
            for name in ('head_pose','body_pose'):
                cfg.commands[name].ranges = tuple((0.,0.) for _ in cfg.commands[name].ranges)
            cmd = cfg.commands['twist']
            cmd.rel_standing_envs = 1.
            for name in ('lin_vel_x','lin_vel_y','ang_vel_z'):
                setattr(cmd.ranges, name, (0.,0.))
            env = ManagerBasedRlEnv(cfg, device=device)
            try:
                state = recovery._sc0090_recovery_state(env)
                state.stage = stage
                obs, _ = env.reset()
                invalid = torch.zeros(env.num_envs, dtype=torch.bool, device=device)
                first = torch.full((env.num_envs,), float('inf'), device=device)
                for step in range(400):
                    obs, _, _, _, _ = env.step(policy(obs))
                    stable = recovery.sc0090_stable_standing(env).bool()
                    first = torch.where(stable & torch.isinf(first), (step+1)*.02, first)
                    invalid |= ~torch.isfinite(env.sim.data.qpos).all(-1)
                    feedback = getattr(env, '_v2_joint_feedback', None)
                    if feedback is not None:
                        invalid |= ~feedback.ready
                success = state.success & stable & ~invalid
                groups = {}
                for i, name in enumerate(recovery.SC0090_RECOVERY_BUCKETS):
                    mask = state.bucket == i
                    passing = mask & success
                    groups[name] = dict(trials=int(mask.sum()), wins=int(passing.sum()),
                        any_stable=int((mask & state.success).sum()), faults=int((mask & invalid).sum()),
                        first_stable_mean_s=float(first[passing].mean()) if passing.any() else None)
                cases.append(dict(seed=seed, finite=bool(torch.isfinite(env.sim.data.qpos).all()), groups=groups))
            finally:
                env.close()
    finally:
        policy.train(was_training)
        torch.set_rng_state(cpu_rng)
        torch.cuda.set_rng_state_all(cuda_rng)
        np.random.set_state(numpy_rng)
        random.setstate(python_rng)
    return cases


def main():
    p = argparse.ArgumentParser(__doc__)
    p.add_argument('--task', required=True)
    p.add_argument('--device', required=True)
    p.add_argument('--output', type=Path, required=True)
    p.add_argument('--num-envs', type=int, default=8192)
    p.add_argument('--iterations', type=int, default=1000)
    p.add_argument('--eval-interval', type=int, default=500)
    p.add_argument('--eval-samples', type=int, default=128)
    p.add_argument('--preflight', type=Path, required=True)
    p.add_argument('--resume', type=Path)
    p.add_argument('--validation-only', action='store_true')
    args = p.parse_args()
    if args.num_envs != 8192 and not args.validation_only:
        p.error('Formal V2 allocations use the user-requested 8192 environments')
    smoke = json.loads(args.preflight.read_text())
    assert smoke['status'] == 'PASS' and smoke['task'] == args.task
    assert smoke['physics_cuda_graph'] and min(smoke['motor_graph_replays']) > 0
    output = args.output.resolve()
    output.mkdir(parents=True, exist_ok=False)
    torch.set_num_threads(2)
    root = Path(__file__).resolve().parents[1]
    sources = sorted([*root.glob('src/**/*.py'), *root.glob('src/**/*.cpp'),
                      root/'scripts/train_v2_standup.py', root/'scripts/v2_python.sh'])
    hashes = {str(f.relative_to(root)):hashlib.sha256(f.read_bytes()).hexdigest() for f in sources}
    with tarfile.open(output/'source.tar.gz', 'w:gz') as archive:
        for f in sources:
            archive.add(f, arcname=str(f.relative_to(root)))
    cfg = load_env_cfg(args.task)
    cfg.seed, cfg.scene.num_envs = 20261015, args.num_envs
    agent = load_rl_cfg(args.task)
    agent.logger, agent.upload_model, agent.save_interval = 'tensorboard', False, 250
    agent.seed = cfg.seed
    write_json(output/'run.json', dict(task=args.task, device=args.device, num_envs=args.num_envs,
        allocation_updates=args.iterations, evaluation_interval=args.eval_interval,
        evaluation_samples_per_bucket_per_seed=args.eval_samples,
        seed=cfg.seed, source_sha256=hashes,
        git_head=subprocess.check_output(['git','rev-parse','HEAD'],cwd=root,text=True).strip(),
        dependencies={n:importlib.metadata.version(n) for n in
                      ['torch','mjlab','mujoco','mujoco-warp','warp-lang','better-actuator-models','rsl-rl-lib']},
        preflight=str(args.preflight.resolve()), agent=asdict(agent), environment=asdict(cfg),
        resume=str(args.resume) if args.resume else None))
    class StopRequested(Exception):
        pass
    stopping = False
    def stop(*_):
        nonlocal stopping
        stopping = True
    signal.signal(signal.SIGTERM, stop)
    signal.signal(signal.SIGINT, stop)
    env = ManagerBasedRlEnv(cfg, device=args.device)
    assert env.sim.use_cuda_graph
    counts = wp.to_torch(env.sim.wp_data.nacon)
    native_step = env.sim.step
    def checked_step():
        native_step()
        torch._assert_async((counts <= env.sim.wp_data.naconmax).all(), 'V2 Warp contact overflow')
    env.sim.step = checked_step
    wrapped = RslRlVecEnvWrapper(env, clip_actions=agent.clip_actions)
    # Identical network initialization despite distinct feedback setup RNG use.
    torch.manual_seed(cfg.seed + 100)
    runner = load_runner_cls(args.task)(wrapped, asdict(agent), str(output), args.device)
    completed = 0
    if args.resume:
        infos = runner.load(str(args.resume))
        completed = infos['v2']['completed_updates']
        state = recovery._sc0090_recovery_state(env)
        state.load_state_dict(infos['v2']['recovery'])
        env._sc0090_eval_history = infos['v2'].get('eval_history', {})
        runner.current_learning_iteration = completed
        torch.set_rng_state(infos["v2"]["torch_rng"].cpu())
        torch.cuda.set_rng_state_all([r.cpu() for r in infos["v2"]["cuda_rng"]])
    start = completed
    original_update = runner.alg.update
    def checked_update():
        nonlocal completed
        result = original_update()
        completed += 1
        if any(not np.isfinite(float(v)) for v in result.values()):
            raise FloatingPointError(f'Nonfinite PPO losses: {result}')
        if completed % 10 == 0 or completed <= start+5:
            write_json(output/'status.json', dict(status='RUNNING',pid=os.getpid(),
                completed_updates=completed, allocation_end=start+args.iterations,
                controls=completed*args.num_envs*agent.num_steps_per_env,
                common_step_counter=env.common_step_counter,
                updated_unix=time.time(), losses=result,
                recovery_stage=recovery._sc0090_recovery_state(env).stage))
        if stopping:
            raise StopRequested()
        return result
    runner.alg.update = checked_update
    original_save = runner.save
    def save(path, infos=None):
        state = recovery._sc0090_recovery_state(env)
        infos = {**(infos or {}),'v2':dict(completed_updates=completed,
            recovery=state.state_dict(),eval_history=getattr(env,'_sc0090_eval_history',{}),
            source_sha256=hashes, physics_resume='native-new-episodes',
            torch_rng=torch.get_rng_state(), cuda_rng=torch.cuda.get_rng_state_all())}
        original_save(path, infos)
    runner.save = save
    try:
        while completed < start+args.iterations and not stopping:
            amount = min(args.eval_interval, start+args.iterations-completed)
            runner.current_learning_iteration = completed
            try:
                runner.learn(amount, init_at_random_ep_len=False)
            except StopRequested:
                runner.current_learning_iteration = completed
                save(str(output/f'checkpoint_{completed:06d}.pt'))
                break
            if runner.logger.writer is not None:
                runner.logger.writer.flush()
                runner.logger.writer.close()
            runner.current_learning_iteration = completed
            checkpoint = output/f'checkpoint_{completed:06d}.pt'
            save(str(checkpoint))
            if stopping:
                break
            state = recovery._sc0090_recovery_state(env)
            request = dict(schema=1,checkpoint_sha256=hashlib.sha256(checkpoint.read_bytes()).hexdigest(),
                config_sha256=hashlib.sha256((output/'run.json').read_bytes()).hexdigest(),
                iteration=completed,stage=state.stage,seeds=[2026101501,2026101502],
                samples_per_group=args.eval_samples,duration_s=8.,deterministic=True)
            with torch.inference_mode():
                report = {**request,'cases':evaluate(args.task,runner.alg.get_policy(),args.device,state.stage,args.eval_samples)}
            decision = recovery.sc0090_apply_recovery_evaluation(env,report,request)
            write_json(output/f'evaluation_{completed:06d}.json', {**report,'decision':decision})
            # Only proved recovery competence enables smoothing and head polish.
            if state.polish:
                for name, weight in (('action_rate_l2',-.5),('arrival_damping',-.025),
                    ('joint_torque_rate_l2',-.0005),('head_pose_bias',.5),('body_pose_tracking',.5)):
                    env.reward_manager.get_term_cfg(name).weight = weight
            save(str(checkpoint))
        write_json(output/'status.json', dict(status='STOPPED' if stopping else 'ALLOCATION_COMPLETE',
            pid=os.getpid(),completed_updates=completed,updated_unix=time.time(),
            goal_complete=False, recovery_stage=recovery._sc0090_recovery_state(env).stage))
    finally:
        env.close()


if __name__ == '__main__':
    main()
