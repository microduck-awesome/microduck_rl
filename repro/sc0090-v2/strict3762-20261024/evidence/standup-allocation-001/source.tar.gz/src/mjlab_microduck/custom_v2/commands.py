"""GPU sampling of idle, single-axis, paired and combined head requests."""
from dataclasses import dataclass
import torch
from mjlab_microduck.tasks.mdp import UniformPoseCommand, UniformPoseCommandCfg


def sample_head(ranges, n, device, zero_probability):
    bounds = torch.tensor(ranges, device=device)
    values = bounds[:, 0] + torch.rand(n, 4, device=device) * (bounds[:, 1] - bounds[:, 0])
    # Keep endpoints represented as the curriculum widens; random interiors
    # still dominate, rather than learning a small set of fixed button poses.
    endpoint = torch.where(torch.rand(n, 4, device=device) < .5, bounds[:, 0], bounds[:, 1])
    values = torch.where(torch.rand(n, 4, device=device) < .2, endpoint, values)
    u = torch.rand(n, device=device)
    active = (u - zero_probability) / (1 - zero_probability)
    counts = torch.where(active < .5, 1, torch.where(active < .75, 2, 4))
    counts = torch.where(u < zero_probability, 0, counts)
    ranks = torch.rand(n, 4, device=device).argsort(-1).argsort(-1)
    return values * (ranks < counts[:, None])


class BalancedHeadCommand(UniformPoseCommand):
    def _resample_command(self, env_ids):
        self._command[env_ids] = sample_head(self.cfg.ranges, len(env_ids), self.device,
                                             self.cfg.zero_command_prob)


@dataclass(kw_only=True)
class BalancedHeadCommandCfg(UniformPoseCommandCfg):
    def build(self, env):
        if len(self.ranges) != 4 or not 0 <= self.zero_command_prob < 1:
            raise ValueError('Four head axes and a nontrivial active sampling probability are required')
        return BalancedHeadCommand(self, env)
